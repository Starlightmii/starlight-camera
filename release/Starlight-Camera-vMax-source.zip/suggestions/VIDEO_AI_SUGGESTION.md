# VIDEO_AI_SUGGESTION.md — Topaz-style video enhancement, smoothing and upscaling for Starlight Camera vMax

**Audience:** the subagent that owns the APK patching / `classes4.dex` code.
**Read together with `SUGGESTION.md`.** That file fixes the video *plumbing* (extractor → decoder → OES → GL → encoder surface → muxer, MediaStore save, FGS, diagnostics). This file says *what to put inside the GL stage* so the app does what Topaz Video AI does, within what a Snapdragon 732G can actually run, and how to scale that to other devices.

**How I read the request:** "like Topaz AI, without changing resolution, AI frames, more smooth, upscale" = three separate features:

1. **Clean / Enhance at the *same* resolution** (Topaz "Enhancement" with 1× scale: denoise, detail recovery, sharpen).
2. **Smooth** (frame interpolation: 24/30 → 48/60 fps — Topaz Apollo/Chronos/Aion).
3. **Upscale** (resolution change — already covered in `SUGGESTION.md` §4; here it is just one optional stage).

Confidence tags: **[known]** documented/published; **[likely]** strong inference; **[guess]** my estimate, measure it; **VERIFY** needs an on-device test.

---

## 0. Bottom line

1. **Topaz-class neural video enhancement cannot run on a Snapdragon 732G at a usable speed.** Not "slow" — orders of magnitude off. Even Google processes Pixel "Video Boost" in the cloud, taking hours, because a 1-minute 4K30 clip is ~1,800 photos of work.
2. **But ~80 % of what people *see* in Topaz on phone footage comes from three classical operations that a mid-range GPU does easily:** (a) motion-compensated **temporal denoise**, (b) edge-aware **spatial denoise**, (c) **contrast-adaptive sharpening applied after denoising**. That stack at native resolution should run around real-time to 2× real-time at 1080p on Adreno 618 **[guess]** and it is the best value-per-watt feature you can ship. Call it **Clean** (not "AI") unless a learned model is actually in the loop.
3. **"Without changing resolution" is the cheapest, fastest and most useful mode.** It avoids the expensive 4K path entirely (no 8.3 MP shader, no 4K encode) and the output is the same size as the source.
4. **Smooth (frame interpolation) is feasible only as classical motion-compensated interpolation with a hard fallback to frame-hold, at ≤ 1080p60.** RIFE-class neural interpolation needs a desktop RTX 3070-class GPU for real-time 1080p, or a flagship NPU with special tricks. On this device it is a PC-offload feature, not an on-device one. **Also: the SD732G's hardware encoder almost certainly tops out at 4K30**, so *4K upscale and 60 fps are mutually exclusive on this phone* (check `areSizeAndRateSupported`).
5. **The cheapest "smooth" is to record at 60 fps in the first place.** Interpolating 30→60 can never beat native 60.
6. **ML belongs behind a pluggable interface, off by default.** Use it only (a) on stills, (b) on devices that benchmark well, (c) offline while charging, or (d) offloaded to a PC/cloud. The app's real unfair advantage over Topaz is that **it is the camera**: it can know ISO/exposure/noise profile at capture time and use a physically-correct noise model instead of guessing (§4.4).
7. **Order of operations is fixed:** `denoise → (deblock/deband) → sharpen → (optional resize) → (optional interpolate) → encode`. Sharpening before denoising amplifies noise; interpolating noisy frames amplifies flicker.
8. **Bandwidth, not FLOPs, is the Adreno 618 limiter** (≈ 15 GB/s). Fuse passes, keep everything RGBA8, avoid 4K intermediates (§3.3).

---

## 1. What Topaz does, and what it costs (research)

### 1.1 Topaz model families → what each does → the phone-feasible equivalent

| Topaz model(s) | What it does | Phone-feasible equivalent here |
|---|---|---|
| **Nyx** (and Nyx Fast/XL), **Artemis** (denoise/sharpen, same-res), parts of **Proteus** | Noise reduction + compression-artifact recovery; Artemis is the classic "denoise + sharpen at same resolution" model; Nyx is noted for low light and for being the least distorting; benefit is small on well-lit footage | **Clean:** MC temporal denoise + edge-aware spatial denoise + CAS-style sharpen (§4) |
| **Proteus** | General-purpose workhorse with manual sliders (compression recovery, detail, sharpen, noise, dehalo, anti-alias/deblur) | The same Clean stack with user sliders: *Denoise*, *Detail*, *Sharpen* |
| **Iris** | Low-quality input, face/fine-detail recovery | No equivalent on-device. Optional luma-detail boost only |
| **Rhea / Gaia / Theia** | Upscalers / fidelity or CG-specific enhancement | **Upscale:** Catmull-Rom / SGSR1 / EASU (`SUGGESTION.md` §4) |
| **Themis** | Motion deblur | Skip (needs motion-aware deconvolution; heavy, artifact-prone) |
| **Apollo / Apollo Fast / Chronos / Chronos Fast / Aion** | Frame interpolation (clean 2×/4×/8×; general retime; heavy slow-mo) | **Smooth:** classical MC interpolation, 2× only (§5). Neural → PC offload |
| **Starlight / Astra** | Diffusion/generative restoration/upscaling (cloud-credit models) | Impossible on-device. Cloud only |
| Stabilization, SDR→HDR | — | Out of scope (GCam already stabilizes; HDR sources are skipped) |

User-community observations worth designing around: Topaz's own docs describe chaining models (e.g. a denoiser then a detail model) when one model cannot fix both noise and detail; and frame interpolation visibly stutters when the *source* already has irregular timing — interpolation does not repair bad cadence.

### 1.2 What it costs

- **Desktop-class GPU, published reviews:** Proteus 4× on a 30 s 720p60 clip → 4K took roughly 12–14 minutes; Nyx denoise on a 30 s 25 fps clip took roughly a minute. Those are PC numbers.
- **Google Pixel Video Boost** (the industry's own mobile answer): the phone records a second "RAW-ish" copy, uploads it, and the cloud returns the processed clip — hours for a few minutes of video. Google's stated reason: one minute of 4K30 is the same as processing about 1,800 photos, which no phone can do alone. They still ship fast on-device features (stabilization, Live HDR+) and keep the heavy part off the phone. **Your design should follow the same split:** cheap classical processing on the phone, heavy neural work optional and offloaded.

---

## 2. What the SD732G / Adreno 618 can actually do

### 2.1 Hardware facts (published)

| Item | Value | Implication |
|---|---|---|
| GPU | Adreno 618, ~0.95 GHz; WikiChip lists ≈ **422 GFLOPS** (fp32). SD732G is "up to 15 % faster" than SD730G | Fine for fragment-shader image processing; weak for CNNs |
| Memory | LPDDR4X dual-channel 16-bit @ 1866 MHz ≈ **14.9 GB/s** | **The real bottleneck.** One 1080p RGBA8 read+write pass ≈ 16 MB ≈ 1.1 ms *just in bandwidth* |
| AI engine | 4th-gen, Hexagon 688 (HVX + Tensor Accelerator), marketing "up to 3.6 TOPS" (some tables list 4.0) | INT8/INT16 only; usable only if the ROM's NNAPI/delegate path exposes it. **VERIFY** |
| APIs | OpenGL ES 3.2, Vulkan 1.1, OpenCL 2.0 | ES 3.x compute-free pipeline is fine |
| Encoder (see note) | HEVC/H.264 4K30 encode/decode class | 4K60 and "4K upscale + interpolation" are not possible; confirm with `VideoCapabilities` |

### 2.2 The best published mobile-GPU video-SR data point, scaled to this phone

The Mobile AI 2021 *Real-Time Video Super-Resolution* challenge ran 50–230 KB TFLite models on an OPPO Find X2 (Snapdragon 865, Adreno 650, ~2.4 TFLOPS FP16) with the TFLite GPU delegate: **10 frames 320×180 → 1280×720 in ~113–199 ms**, i.e. roughly 50–90 fps at 720p output — with models that are tiny and trained on blurry, bicubic-degraded REDS data.

Scaling to your case (arithmetic, **[guess]**):

- Adreno 650 ≈ 2.5–3× Adreno 618 in raw FLOPs and ≈ 3× in memory bandwidth → assume **~3× slower** on Adreno 618.
- The cost of those nets is driven by *input* pixels (they work at LR resolution). Benchmark LR frame = 57.6 K px at ~11–20 ms on A650. A **1080p input is 2.07 M px = 36×** more.
- → even the tiniest net ≈ **0.4–0.7 s/frame on A650, ≈ 1.2–2 s/frame on A618 (0.5–0.8 fps)**. A 30 s 30 fps clip = 900 frames ≈ 20–30 min. That is "overnight while charging", not "after recording".
- Real-ESRGAN class models are far heavier: a public Android benchmark (MNN + Real-ESRGAN, Vulkan) reports about **3 minutes for one 1080p→4K image on a Snapdragon 855**.

### 2.3 Frame interpolation data points

- **RIFE** (the standard neural interpolator): real-time *desktop* playback tables put 1080p@48 fps at ≥ RTX 3070-class with generic Vulkan; mobile real-time work (e.g. the ANVIL paper, 1080p 30→60 on a Snapdragon 8 Gen 3 at ~13 ms/frame INT8) needs a flagship NPU *and* a redesigned model that uses **codec motion vectors as priors**, and shows plain RIFE/IFRNet hit operator and quantization barriers on mobile NPUs. A community report on `rife-ncnn-vulkan` for Android notes the **CPU path is often faster than the Vulkan GPU path** on phones. → Not for Adreno 618.
- **Qualcomm AFME (Adreno Frame Motion Engine) / Adreno Motion Engine / Adreno Neural Fusion:** game-engine frame generation/extrapolation (needs engine-supplied motion vectors/depth), OEM-gated, on 8 Gen 3 / 8 Elite / newer and the 6 Gen 4 roadmap; ANF is stated for Snapdragon 8 Elite Gen 6 and above. **None of it is available to a camera app on Adreno 618.**
- **Lossless-Scaling-style GPU frame generation was ported to Android on Adreno 6xx** (community, tested on an Adreno 619 phone). That tells you *classical, shader-only* frame generation is feasible on 6xx GPUs — at low resolution and with artifacts — which supports the §5 design for offline use.

### 2.4 Denoising data points

- **Google's own mobile algorithm** (Ehmann et al., ICIP 2018, "Real-Time Video Denoising on Mobile Phones"): Gaussian–Laplacian pyramid decomposition, fast alignment, and a robust adaptive merge of noisy frames; **< 20 ms per HD frame** on a modern mobile platform of that time, with quality comparable to offline methods. This is the template for §4 — classical, GPU-friendly, proven on phones.
- **FastDVDnet** (best-known lightweight neural video denoiser, no flow estimation): ~100 ms for a 960×540 frame on a Titan Xp desktop GPU. Far too heavy for Adreno 618.

**Conclusion of §2:** on this phone, *classical multi-pass GPU processing* is the only on-device option for video; neural nets are a stills / offline / offload feature.

---

## 3. Recommended design: Clean → Smooth → Upscale, all in the GL stage

### 3.1 User-facing modes

| Mode | What it does | Resolution | FPS | Encode cost | Default |
|---|---|---|---|---|---|
| **Clean** | MC temporal denoise + spatial denoise + CAS-style sharpen | **= source** | = source | like re-recording | **ON for tiers A–C** |
| **Clean+ (low light)** | Same, stronger temporal/spatial, auto-selected when noise estimate is high | = source | = source | same | auto |
| **Smooth** | Clean + 2× frame interpolation | = source (≤ 1080p) | 2× (≤ 60) | ~2× frames | OFF (opt-in) |
| **Upscale** | Clean + 1.33×/1.5×/2× resize | up | = source (cap 30 at 4K) | high | OFF (opt-in) |
| **Max (offload)** | Neural enhance/interpolate on PC or cloud | any | any | none on phone | opt-in |

Never advertise Clean/Smooth as "AI" unless a learned model runs. Clean/Natural/Smooth are honest names.

### 3.2 Per-frame pipeline (extends `SrVideoTranscoder`, `SUGGESTION.md` §2.3)

```
decoder ──▶ SurfaceTexture ──▶ Pass 1: OES → RGBA8 FBO "cur" (source res, applies transform matrix)
                                          │
                  ┌───────────────────────┴───────────────────────┐
                  ▼                                               ▼
   Luma pyramids of cur and prevOut                  (stats: noise σ estimate, scene-cut score)
   L1 = 1/2, L2 = 1/4  (3 tiny passes)
                  ▼
   Block matching: L2 (±3, 8×8)  →  L1 refine (±1)  →  L0 refine (±1)   ⇒  MV field + SAD
                  ▼
   Pass C: temporal merge (MC history, neighbourhood clamp, robust weight)
           + light edge-aware spatial denoise (fused)         ⇒ FBO "out[N]"
                  ▼
   Pass D: CAS-style luma sharpen (+ optional resize, §6)     ⇒ encoder window surface (frame N)
                  │
   (Smooth only)  └─ mid-frame synthesis from out[N-1], out[N], MV01/MV10 ⇒ encoder surface at PTS (N-1+N)/2
```

Ping-pong: `out[N]` becomes `prevOut` for N+1 (recursive filter — equivalent to a long temporal window at the cost of one extra fetch). Decode order = presentation order from the codec, so recursion is valid. Reset history on scene cuts and at the first frame.

### 3.3 Cost model for Adreno 618 **[guess — measure with `GL_EXT_disjoint_timer_query`]**

Bandwidth-bound arithmetic for 1080p (2.07 MP, RGBA8 = 8.3 MB per full read or write):

| Stage | Reads + writes | ≈ ms @ 14.9 GB/s |
|---|---|---|
| Pass 1 (OES → cur) | decoder buffer read + 8.3 MB write | ~1.0 |
| Pyramids (L1 + L2, luma only) | small | ~0.3 |
| Block matching (L2/L1/L0) | ~16 M tiny fetches, MV textures ~ 120×68 | ~1–2 |
| Merge + spatial denoise (fused) | cur + prev + (mv) read, out write ≈ 25 MB | ~1.7 |
| CAS sharpen → encoder surface | 8.3 MB read + 8.3 MB write | ~1.1 |
| **Total (Clean, 1080p)** | | **≈ 5–8 ms → 100+ fps theoretical; expect 25–50 fps real** |

So **Clean at 1080p ≈ 1–2× real-time**; a 30 s clip in roughly 15–40 s, bounded mostly by the hardware encoder and thermals. The same arithmetic at 4K (4× the pixels, 33 MB per full buffer) is ~4× that, and the encoder also has to take RGBA at 4K — which is why *upscaling is the expensive feature, not enhancing.*

**Rules that follow from the bandwidth limit:**
- Fuse passes whenever you can (merge + spatial denoise in one shader; sharpen + resize in one shader).
- Keep everything **RGBA8** (no fp16 FBOs unless a pass genuinely needs them; encode MVs in RGBA8 with a bias).
- No intermediate larger than the source size except the final output.
- Use luma-only textures (`GL_LUMINANCE`/R8 where available) for pyramids and block matching.

---

## 4. Clean — same-resolution enhancement (the main event)

### 4.1 Why this is the best value

Phone video's visible weaknesses are, in order: **noise (low light/indoor), over-aggressive in-ISP smoothing + blocky mush, soft detail.** Temporal denoise with correct alignment removes noise *without* destroying detail (it averages the same scene point over time), which is why every serious mobile video pipeline (Google's, Topaz's Nyx/Artemis family) is built around it. It is also cheap: two extra texture fetches per pixel.

### 4.2 Temporal denoise: alignment + robust merge

**Alignment — hierarchical block matching on luma** (cheap, deterministic, no model):

```glsl
// bm_coarse.frag — one fragment per 8x8 block at level 2 (1/4-res luma). Output: RG = motion+bias, B = SAD.
precision highp float;
uniform sampler2D uCur;        // luma in .r, level 2
uniform sampler2D uPrev;       // luma of the PREVIOUS OUTPUT frame, level 2
uniform vec2 uInvSize;         // 1 / level-2 texture size
uniform vec2 uBlockCount;      // block grid size
varying vec2 vTc;              // 0..1 across the block grid

void main() {
    vec2 blk  = floor(vTc * uBlockCount);
    vec2 base = blk * 8.0 + 0.5;                          // block top-left in texel coords (+0.5 = texel centre)
    float best = 1e9; vec2 bestMv = vec2(0.0);
    for (int j = -3; j <= 3; j++) {
        for (int i = -3; i <= 3; i++) {
            float sad = 0.0;
            for (int y = 0; y < 8; y += 2) {              // 4x4 subsample of the 8x8 block (speed)
                for (int x = 0; x < 8; x += 2) {
                    vec2 p = (base + vec2(float(x), float(y))) * uInvSize;
                    sad += abs(texture2D(uCur, p).r - texture2D(uPrev, p + vec2(float(i), float(j)) * uInvSize).r);
                }
            }
            sad += 0.002 * (abs(float(i)) + abs(float(j)));   // bias toward zero motion (regularisation)
            if (sad < best) { best = sad; bestMv = vec2(float(i), float(j)); }
        }
    }
    gl_FragColor = vec4(bestMv / 16.0 + 0.5, clamp(best / 16.0, 0.0, 1.0), 1.0);   // 8-bit safe
}
```

- **Refine passes** (`bm_refine`): same structure, start at `2 × (MV from the coarser level, decoded and nearest/bilinear-upsampled)`, search ±1 (9 candidates), 16×16 blocks on L1 then L0. Total fetch count for the three levels at 1080p ≈ 16 M — trivial.
- The MV texture is sampled with **LINEAR** filtering in the merge pass, which gives smooth per-pixel motion (a cheap stand-in for overlapped-block motion compensation) and avoids block seams.
- ±3 px at 1/4 res ≈ ±12 px at full res, ±1 each refinement ≈ ±18 px/frame total. Faster motion → high SAD → weight → 0 → that region simply isn't temporally filtered. That is the *safe* failure mode.

**Merge — robust, recursive, with a TAA-style ghost clamp:**

```glsl
// temporal_merge.frag
precision highp float;
uniform sampler2D uCur;      // current frame RGB (source res)
uniform sampler2D uPrev;     // previous OUTPUT frame RGB
uniform sampler2D uMv;       // final MV field: RG = mv_px/32 + 0.5, B = block SAD (0..1)
uniform sampler2D uStats;    // 1x1: .r = global mean SAD (scene-cut score)
uniform vec2  uInvSize;
uniform float uSigma;        // noise std-dev, gamma-encoded 0..1 units (≈0.008 clean … 0.04 very noisy)
uniform float uWMax;         // max history weight (0.6 .. 0.85)
varying vec2 vTc;
const vec3 L = vec3(0.2126, 0.7152, 0.0722);

void main() {
    vec3 c  = texture2D(uCur, vTc).rgb;
    vec4 m  = texture2D(uMv,  vTc);
    vec2 mv = (m.rg - 0.5) * 32.0 * uInvSize;                       // motion in uv units
    vec3 p  = texture2D(uPrev, vTc + mv).rgb;                       // motion-compensated history

    // Neighbourhood clamp of the history to the current frame's local range (kills ghosts)
    vec3 n0 = texture2D(uCur, vTc + vec2(-uInvSize.x, 0.0)).rgb;
    vec3 n1 = texture2D(uCur, vTc + vec2( uInvSize.x, 0.0)).rgb;
    vec3 n2 = texture2D(uCur, vTc + vec2(0.0, -uInvSize.y)).rgb;
    vec3 n3 = texture2D(uCur, vTc + vec2(0.0,  uInvSize.y)).rgb;
    vec3 lo = min(min(c, n0), min(min(n1, n2), n3));
    vec3 hi = max(max(c, n0), max(max(n1, n2), n3));
    p = clamp(p, lo - 1.5 * uSigma, hi + 1.5 * uSigma);

    float d       = abs(dot(c - p, L));
    float wNoise  = exp(-(d * d) / (8.0 * uSigma * uSigma));          // trust history only if the difference looks like noise
    float wMotion = 1.0 - smoothstep(0.35, 0.70, m.b);                // block SAD high → alignment unreliable
    float wScene  = 1.0 - smoothstep(0.30, 0.50, texture2D(uStats, vec2(0.5)).r);   // scene cut → no history
    float w       = uWMax * wNoise * wMotion * wScene;
    gl_FragColor  = vec4(mix(c, p, w), 1.0);
}
```

Design notes:
- `uWMax = 0.75` ≈ an effective temporal window of ~4 frames; `0.85` for very noisy low-light clips.
- The scene-cut score comes from averaging the block SAD down to a 1×1 texture (a few tiny downsample passes) — **no CPU readback needed**, the shader reads it directly. (If you do want it on the CPU for logging, one 1×1 `glReadPixels` per frame is acceptable offline.)
- Process **luma-driven weights, apply to RGB**; chroma noise is usually worse and spatially lower-frequency, so allow a slightly higher weight for chroma if you move to YCoCg.
- Add 1–2 frames of **lookahead** later if you want symmetric (past + future) filtering; recursive-causal is the cheap v1.

**Fused spatial denoise:** immediately after the merge, in the *same* shader or the next fused pass, apply a 3×3 (or 5-tap cross) edge-aware filter whose strength is `uSpatial × (1 − w)` — i.e. smooth more where temporal merging couldn't help (motion, scene start). Weights: `exp(−Δluma²/(2·(2σ)²))`. This is a bilateral-lite filter, one pass, ~5 fetches.

### 4.3 Sharpen (after denoise, never before) — contrast-adaptive

AMD FidelityFX **CAS** is exactly the right shape (MIT-licensed, designed to sharpen adaptively while minimizing halos); this is a CAS-style luma-preserving version:

```glsl
// cas_like.frag  (a=up b=left c=centre d=right e=down, all RGB 0..1)
vec3 mn = min(min(min(a, b), min(c, d)), e);
vec3 mx = max(max(max(a, b), max(c, d)), e);
vec3 amp = sqrt(clamp(min(mn, 1.0 - mx) / max(mx, 1e-3), 0.0, 1.0));   // less sharpening near clipping/high contrast
float peak = -1.0 / mix(8.0, 5.0, uSharp);                              // uSharp 0..1
vec3 w = amp * peak;
vec3 rgb = clamp((w * (a + b + d + e) + c) / (1.0 + 4.0 * w), 0.0, 1.0);
```

- Default `uSharp ≈ 0.25–0.35`. Scale it by `(1 − noiseEstimate)` so noisy clips aren't re-sharpened into grain.
- When a resize is wanted, combine with Catmull-Rom/SGSR1 from `SUGGESTION.md` §4.1 (SGSR1 already integrates adaptive sharpening in the same pass).
- Do **not** use the old linear contrast stretch (`SUGGESTION.md` §4.4). If you want contrast, use an endpoint-preserving curve.

### 4.4 Noise model — the app's advantage over Topaz

Topaz has to *guess* the noise level from pixels. A camera app can *know* it.

- **At capture:** Camera2 exposes ISO/exposure time per frame, and `SENSOR_NOISE_PROFILE` (per-channel `(S, O)` parameters: noise variance ≈ `S·signal + O` in the raw linear domain). That is the physically correct input to a temporal-merge weight (it is what burst/HDR+ pipelines use). **VERIFY** that the ported HAL actually reports it; many ported camera stacks do not.
  - Practical plan: when recording stops, write a small **sidecar JSON** in app-private storage keyed by the video's `DISPLAY_NAME` with min/median/max ISO, exposure time, and the noise profile (if present). The enhancer reads it; if it's missing, fall back to blind estimation. Finding the recording-stop hook in obfuscated GCam smali is the hard part — treat as P2.
- **Blind estimate (always implement; it is the fallback and works on any file):** on the first ~10 frames, compute the median of `|Laplacian|` (or the MAD of the high-pass residual) over the *flattest 25 %* of 16×16 blocks (lowest gradient energy), `σ ≈ 1.4826 · MAD / √(Laplacian-kernel energy)`. Smooth it over time; clamp to `[0.004, 0.05]`. Re-estimate every ~2 s so exposure changes are tracked.
- **Strength policy:** `strength = smoothstep(0.006, 0.03, σ)` → daylight clips get light filtering (the ISP already denoised them; double-denoising makes plastic skin — Topaz users make the same observation that denoisers help little on well-lit footage), low-light clips get the strong preset automatically. Expose a manual slider on top.

### 4.5 Deblock / deband — skip in v1

GCam clips are recorded at a healthy bitrate; macroblocking is rarely the issue (it is a problem for downloaded/social-media clips). Skip the deblocker. If you later want one: detect the codec grid (16×16 for AVC), smooth across block edges where the cross-edge step is small relative to the in-block gradient. Banding: add ±0.5 LSB blue-noise dither in the final pass when the clip has large flat gradients (sky) — nearly free.

### 4.6 Failure modes and guards (these are what make or break the feature)

| Artifact | Cause | Guard |
|---|---|---|
| **Ghosting / trailing** behind moving objects | History blended where alignment failed | Neighbourhood clamp; `wMotion` from SAD; `wNoise` gating; cap `uWMax`; reset on scene cut |
| **Plastic / waxy skin** | Over-strong spatial denoise, double denoising on already-clean clips | Noise-adaptive strength; spatial strength tied to `(1 − w)`; modest default; user slider |
| **Flicker / "boiling"** | Per-frame varying σ or hard thresholds | Smooth σ over time; use `smoothstep`/`exp`, never hard thresholds |
| **Smeared fine detail** (text, foliage) in motion | MV wrong at small objects | Block-level SAD confidence; smaller blocks at L0; keep `wMotion` conservative |
| **Rolling-shutter wobble misaligned** | Block matching assumes rigid translation per block | Same guards; accept that some regions fall back to spatial-only |
| **Sharpening halos / noise grain** | Sharpen after resize, or on noisy clips | Sharpen after denoise; CAS amp term; scale by `(1 − noise)` |
| **Scene cut ghost** | History carried across cuts | Global SAD score → `wScene` |
| **HDR/10-bit source** | 8-bit SDR shader on HDR frames | Detect (`KEY_COLOR_TRANSFER`, Main10) → skip |

### 4.7 Re-encode rules (an enhancer can *lose* quality if you encode carelessly)

- Same-resolution enhancement re-encodes already-compressed video → **generation loss**. Set output bitrate to `max(sourceBitrate × 1.15, outW·outH·fps·0.17)` (read the source bitrate from the extractor format or `size×8/duration`). Denoised video compresses better, so this spends the bits on detail instead of noise.
- Keep the source's `KEY_COLOR_STANDARD/RANGE/TRANSFER`. Use High profile, 1 s GOP, no B-frames (`SUGGESTION.md` §2.2).
- If the user wants smaller files, offer HEVC (≈ 0.6–0.7× the bits at similar quality) as an explicit toggle.

---

## 5. Smooth — frame interpolation ("AI frames")

### 5.1 Truths to design around

- **Interpolation invents frames; it can't fix a bad source.** Irregular cadence, strong motion blur, rolling shutter and occlusions produce visible artifacts even in Topaz's Apollo/Chronos/Aion (community reports describe stutter after careful tuning). Expect artifacts on fine fast motion, repeated textures, thin objects, and revealed/occluded regions.
- The look changes (the "soap-opera effect"). Cinematic 24 fps footage often should *not* be interpolated. Default **OFF**, opt-in per clip/profile.
- **Shoot at 60 fps if you want smooth video.** GCam/LMC can record 1080p60 on this class of device (**VERIFY** in the camera menu). Native 60 always beats synthesized 60. State this in the settings description.

### 5.2 Encoder limit on SD732G — decides what is possible

Query `VideoCapabilities.areSizeAndRateSupported(w, h, fps)` at runtime. On this SoC I expect: **1080p60 yes, 1440p60 maybe, 4K60 no (4K30 max)**. Consequences:

| Source | Smooth output | Upscale + Smooth |
|---|---|---|
| 1080p30 | 1080p60 ✔ | ✘ on SD732G (4K60 unsupported) — pick one |
| 1080p24 | 1080p48 ✔ (or 60 via 2.5× is not supported — keep 2×) | ✘ |
| ≥ 50 fps | **skip** | — |
| 4K30 | ✘ (4K60 unsupported) | — |

The planner must *refuse impossible combos with a clear message*, not silently pick one.

### 5.3 Classical motion-compensated interpolation (the on-device design)

Reuse the block-matching machinery of §4.2, run **bidirectionally** between the two enhanced neighbours `out[N-1]` and `out[N]`:

1. Estimate `MV01` (N-1 → N) and `MV10` (N → N-1) with the same 3-level matcher.
2. **Forward–backward consistency:** `fb = |MV01(p) + MV10(p + MV01(p))|`; large `fb` ⇒ occlusion/unreliable ⇒ low confidence.
3. Synthesize the mid frame at `t = 0.5`:

```glsl
// midframe.frag  (t = 0.5)
vec2 f   = (texture2D(uMv01, vTc).rg - 0.5) * 32.0 * uInvSize;     // displacement prev→next in uv
vec3 a   = texture2D(uF0, vTc - 0.5 * f).rgb;                       // where this content was in frame N-1
vec3 b   = texture2D(uF1, vTc + 0.5 * f).rgb;                       // where it will be in frame N
float err  = abs(dot(a - b, L));
float conf = (1.0 - smoothstep(0.04, 0.12, err))                    // warped samples agree
           * (1.0 - smoothstep(0.35, 0.70, sad))                    // block match reliable
           * (1.0 - smoothstep(0.5, 2.0, fbPixels));                // forward-backward consistent
vec3 hold = texture2D(uF0, vTc).rgb;                                // frame-hold fallback (no ghosting)
gl_FragColor = vec4(mix(hold, 0.5 * (a + b), conf), 1.0);
```

- **Fallback is frame-hold, not blend.** Where confidence is low you get ordinary 30-fps judder in that region instead of double images. The feature is then *never worse than not having it*, which is the property that makes it safe to ship.
- **Scene cuts:** global SAD above threshold → duplicate the frame (no interpolation across the cut).
- **Timestamps:** order of output per decoded frame `N`: (1) render enhanced `out[N]`, (2) render the mid frame `(N-1, N)` with PTS `(pts[N-1] + pts[N]) / 2`, swap, (3) render `out[N]` to the encoder at `pts[N]`, swap. PTS stay strictly increasing. Set the encoder `KEY_FRAME_RATE` to `2 × sourceFps`. VFR sources work because the midpoint is computed per pair.
- **Bitrate:** ×1.4–1.6 of the Clean bitrate for 2× frames (motion-compensated content compresses well but not for free).
- **Cost [guess]:** two extra block-matching runs + one synthesis pass ≈ +4–6 ms at 1080p; the 60 fps encode is the real load. Aim for ≥ 0.7× real-time at 1080p60.
- **Audio:** untouched passthrough (only video gains frames). Do **not** offer slow-motion retiming in v1 (it needs audio handling).

### 5.4 Neural interpolation, if you want it anyway

- Only via **PC offload** (§8) or on a flagship tier with a benchmarked NPU/GPU path. RIFE v4.x-lite or IFRNet-S are the realistic candidates; quantize and benchmark before committing (the ANVIL work shows plain flow-based models hit operator/quantization problems on mobile NPUs).
- **Research idea (P3, uncertain):** the source H.264 bitstream already carries motion vectors; ANVIL uses smoothed codec MVs as priors to make mobile interpolation cheap. `MediaCodec` does not expose them publicly; getting them means decoding with a bundled FFmpeg (`export_mvs`), which adds an LGPL native dependency and size. Codec MVs are rate-optimised, not true motion, so they need smoothing/validation. Treat as a later experiment, not v1.

---

## 6. Upscale (only when the user wants a resolution change)

Everything in `SUGGESTION.md` §4 applies (Catmull-Rom 9-tap + limiter, SGSR1 option on Adreno, EASU/RCAS option, colour policy). What this document adds:

- **Honest framing:** 1080p→4K adds no real detail; the visible gain on camera footage comes from *Clean*. The real reasons to upscale are (a) playback on 4K screens and (b) platforms that give 4K uploads a higher bitrate/better codec tier than 1080p (a well-known creator-community reason; **[known, not verified here]**). Put that in the setting's description so users choose it knowingly.
- **Order:** Clean at *source* resolution first (4× cheaper than denoising at 4K), then resize, with the sharpen integrated in the resize pass.
- **Cap at 4K30** on SD732G; offer 1.33×/1.5× (1440p/1620p) as the default "Upscale" for tier B/C.
- **Tiny learned upscalers as shaders:** mpv-community shader CNNs (FSRCNNX family, ArtCNN) are literally small CNNs written as GLSL fragment shaders, run in real time on desktop iGPUs for 1080p→4K, and need no ML runtime — which makes them the only "learned" upscaler that could plausibly be ported into your GLES pipeline for tier A/B. Caveats: they upscale **luma**, so you need a separate chroma path; **the licence must be checked before shipping** (I believe FSRCNNX shaders are LGPL-3 — unverified; Anime4K is MIT but anime-specific); and the expected gain over Catmull-Rom/SGSR1 on noisy live-action is modest. Treat as an optional experiment after Clean ships.

---

## 7. Machine learning: where it fits and what to use

### 7.1 Rule of thumb

> No per-frame neural inference on-device for video on tiers B–D. Neural nets are for **stills**, **offline-while-charging on strong devices**, or **offload**.

### 7.2 Runtimes (all must live in the patched APK as native `.so` + a Java wrapper in `classes4.dex`)

| Runtime | Pros | Cons / notes |
|---|---|---|
| **TFLite + GPU delegate** | Permissive licence; the delegate used by the MAI mobile-GPU challenges; works on Adreno 6xx (OpenCL/GL) | Op-set limited; build models with GPU-friendly ops; benchmark with `benchmark_model --use_gpu=true` |
| **TFLite + NNAPI / Hexagon** | Might use the Hexagon 688 (INT8) | Depends on the **ROM's vendor NNAPI driver**; AI Benchmark lists Hexagon 688 as supported by the old Hexagon NN delegate, but that path is legacy. **VERIFY** with AI Benchmark / `benchmark_model --use_nnapi=true` before relying on it |
| **ncnn (Vulkan)** | Many ready-made SR/interp ports (Real-ESRGAN, RIFE) | Adreno 6xx Vulkan driver bugs exist; community reports show CPU sometimes beats GPU on phones; benchmark both |
| **MNN** | Used by public Android Real-ESRGAN apps | Another runtime to maintain |
| **SNPE / QNN** | Best Qualcomm-specific speed | Redistribution/licence and ROM compatibility questions; not recommended for a patched APK |

### 7.3 Candidate models (all **[guess]** on speed; licences to confirm)

- **Stills / offline enhance:** Real-ESRGAN family (BSD-3): the *compact* general model is the realistic phone variant; the full x4plus is minutes per frame even on an 855. Hallucination (plastic faces, invented texture) and per-frame flicker in video are real downsides — Topaz itself needs dedicated temporal handling.
- **Tiny VSR nets** (MAI 2021 winners, 50–230 KB): fast, but trained on blurry bicubic-degraded data, so on real camera video they mostly sharpen compression artifacts. Retraining on realistic degradations (noise + H.264 recompression) would be required.
- **Denoise nets:** FastDVDnet-class are too heavy; there are mobile-GPU denoising challenge models but no drop-in ones I can vouch for.
- **Interpolation:** RIFE-lite/IFRNet-S — PC offload or flagship only.

### 7.4 Make ML pluggable now, ship it later

Define one interface in the transcoder and implement the classical path behind it:

```java
interface FrameEnhancer {
    boolean supports(DeviceProfile d, StreamInfo s);          // capability + benchmark gate
    void init(GlContext gl, StreamInfo s) throws Exception;
    /** Reads `in` (RGBA8, source res), writes `out`; may keep internal history. */
    void process(Texture in, Texture out, FrameMeta meta);    // meta: pts, isSceneCut, noiseSigma, strength
    void release();
}
// Implementations: ClassicalClean (v1), TfliteGpuEnhancer (later), NcnnEnhancer (later)
```

Gate every ML implementation with a **per-device micro-benchmark** (run 8 frames; require projected speed ≥ a threshold, e.g. ≥ 0.5× real-time while charging, else disable). If ML is used for stills only, call it from the photo path (`SUGGESTION.md` §8), not the video loop.

---

## 8. Offload tiers (this is how you get "real Topaz" quality)

1. **Send-to-PC (recommended heavy tier).** The app exports the *original* clip over LAN to a small user-run service (ffmpeg + RIFE/Real-ESRGAN/Video2X/…), receives the result, inserts it with the MediaStore pending flow (`SUGGESTION.md` §5.1), and shows it in the gallery. Mid-range gaming laptop GPUs (e.g. an RTX 3050 6 GB class card) are enough to run RIFE interpolation and compact Real-ESRGAN models offline at a few-to-tens of fps at 1080p **[guess]** — minutes per minute of video. Pairing/discovery can be a QR code + token; keep it LAN-only by default; never upload without consent.
2. **Cloud (opt-in).** Topaz publishes a developer API that exposes its video enhancement/interpolation models (Proteus, Nyx, Artemis, Rhea, Theia, Gaia, Iris, Apollo, … with per-use credits). Google's own Video Boost shows the user experience: instant on-device result, a better version arrives later with a notification. If you offer this: explicit consent screen, upload size/time warning, credits/terms handled by the user's own key, and clear messaging that the video leaves the phone.
3. Both tiers use the same **job queue + notification** as local jobs, and both keep the on-device Clean result as the immediate output.

---

## 9. Device tiers and presets

| Tier | Typical device | Clean | Smooth | Upscale | ML |
|---|---|---|---|---|---|
| **A flagship** | strong GPU/NPU, ≥ 8 GB | Full (pyramid MC, 1080p–4K source) | 1080p60 / 1440p60 if encoder allows | to 4K30 (or 4K60 if supported) | optional, benchmark-gated, charging only; NPU interpolation experiments |
| **B mid (sweetin)** | Adreno 618-class, 6–8 GB | **Full Clean at ≤ 1080p**; 4K sources: Clean-lite or skip | opt-in, **1080p60 only** | opt-in 1.33–1.5×, 4K30 cap for short clips | none on-device; offload |
| **C low** | ≤ 4 GB, weak GPU | **Clean-lite**: motion-adaptive temporal (no MC) + CAS, 720p–1080p | off | off | none |
| **D potato** | no highp fragment, software encoder, ≤ 2–3 GB | off (don't risk capture/ANR) | off | off | none |

**Clean-lite (tier C):** drop the pyramid/block matching; use the merge shader with `mv = 0` (history is still clamped to the current neighbourhood, so moving regions simply get `wNoise ≈ 0`), spatial strength a bit higher, no sharpen unless bandwidth allows. It works well on tripod/low-motion shots and degrades gracefully elsewhere.

**Presets** (the settings a user sees):

| Preset | `uWMax` | spatial | `uSharp` | notes |
|---|---|---|---|---|
| Natural | 0.5 | 0.15 | 0.15 | gentlest, for already-clean clips |
| **Clean (default)** | 0.75 | 0.30 | 0.30 | noise-adaptive via §4.4 |
| Clean+ (low light) | 0.85 | 0.50 | 0.30 | auto when σ high |
| Smooth | Clean + 2× fps | | | 1080p only |

Everything is overridable (Denoise / Detail / Sharpen sliders → `uWMax·spatial / uSharp`).

---

## 10. Integration with the existing pipeline

1. **Where it plugs in:** replace "Pass 2" of `SrVideoTranscoder` (`SUGGESTION.md` §2.3) with the `FrameEnhancer` chain; keep everything else (decoder, encoder surface, drain-every-frame, audio interleave, MediaStore pending, watchdog, FGS).
2. **Same-resolution output:** set `plan.outW/outH = source dims` (aligned), skip the resize; bitrate per §4.7; encoder `KEY_FRAME_RATE` = source fps (or ×2 for Smooth).
3. **History management:** `out[N]` ping-pong textures, pyramids recomputed per frame; reset on the first frame, on `INFO_OUTPUT_FORMAT_CHANGED`, on scene cuts, and after any dropped frame.
4. **Noise σ:** blind estimator in the first 10 frames (§4.4); sidecar JSON later.
5. **Planner gates** (`SUGGESTION.md` §7.2): refuse impossible combos (Smooth + 4K on SD732G); skip HDR, already-≥4K sources, `Upscaled_*` outputs; pick tier from capability probe + the 20-frame calibration; estimate time and storage first.
6. **Queue and power:** heavy modes (Smooth/Upscale/ML) default to **"only while charging"** with a JobScheduler/FGS queue; Clean runs right after recording if the device is cool and not recording.
7. **UI:** one "Video enhancement" settings page: Off / Natural / Clean / Clean+ / Smooth / Upscale; sliders; "When: right after recording / only while charging / manual from the gallery action"; honest descriptions (what it costs in time, size, battery).
8. **Never replace the original** unless the user opts in; name outputs `…_clean.mp4`, `…_smooth.mp4`, `…_up.mp4`; guard against re-processing your own outputs.
9. **Thermals:** reuse the pacing/pause/abort policy; Clean is light, Smooth/Upscale are not.

---

## 11. Testing and metrics

**Test clips (record these once, keep as the regression set):** daylight handheld; indoor low light (ISO high); night street with lights; tripod static scene; fast pan; walking-while-filming; person waving a hand in front of a static background (ghost test); text/signage in motion; foliage; fast-moving small object; scene cut; 60 fps clip; 24 fps cinematic clip; very short clip (1–2 s); already-clean bright clip (over-denoising test); HDR/10-bit clip (must be skipped).

**Clean — objective + visual:**
- *Noise reduction:* std-dev of flat patches before/after (target 40–70 % lower in low light, < 20 % change in daylight).
- *Detail retention:* edge/text sharpness (e.g. MTF50 on a chart clip) must not fall; compare crops at 200 %.
- *Temporal flicker:* variance of frame differences in static regions (should drop).
- *Ghost test:* hand-wave clip; any trailing = fail.
- *Plastic-skin check:* face crops on indoor clips, side-by-side.

**Smooth — hold-out protocol (the only honest way):** take a native 60 fps clip, drop every other frame, interpolate back to 60, and compare against the dropped *real* frames with PSNR/SSIM/VMAF; report the fraction of pixels that fell back to hold. Visually inspect pans, rotations, occlusions, thin objects, repeating textures. Require: never worse than frame-duplication on any test clip.

**System:** use the acceptance criteria from `SUGGESTION.md` §9 (frame counts, validation, no litter, no ANR, flat memory), plus: throughput (ms/frame per pass, with `GL_EXT_disjoint_timer_query`), GPU/thermal over a 3-minute run, and bitrate/file-size per preset.

---

## 12. Phased plan

**Phase 0 (prerequisite):** finish `SUGGESTION.md` Phase 1 (working surface pipeline, valid MP4s, MediaStore pending, diagnostics). Do not start here until frame counts match.

**Phase 1 — Clean-lite:** merge shader with `mv = 0`, blind σ estimate, fused spatial denoise, CAS-style sharpen, same-resolution encode with the bitrate rule. Ship behind a setting. *Exit:* noise down in low light, no ghosting on the hand-wave clip, ≥ 1× real-time at 1080p on sweetin.

**Phase 2 — Clean (full):** pyramids + hierarchical block matching + MV-driven merge + scene-cut handling + presets and sliders + noise-adaptive strength. *Exit:* passes the ghost and plastic-skin tests; ≥ 1× real-time at 1080p.

**Phase 3 — Smooth:** bidirectional matching, forward–backward check, mid-frame synthesis with hold fallback, PTS handling, planner refusal rules, 1080p60 only. *Exit:* never worse than duplication on the hold-out set; encoder accepts 1080p60 on all supported tiers.

**Phase 4 — Capture-time metadata + settings polish:** sidecar JSON from Camera2 metadata (if the HAL provides it), "only while charging" queue, honest UI text.

**Phase 5 — Optional extras:** shader-CNN upscaler experiment (licence check first), `FrameEnhancer` ML implementations behind benchmark gating, PC/cloud offload, codec-MV experiment.

---

## 13. What I could not verify (measure first)

1. **All speed numbers** (§3.3, §5.3): bandwidth/FLOP arithmetic, not measurements. Measure per pass.
2. **The SD732G encoder's real limits** (4K60? 1440p60? max bitrate?) — query `VideoCapabilities` on the device.
3. **Whether this ROM's HAL reports `SENSOR_NOISE_PROFILE`** and per-frame ISO/exposure during video, and where the recording-stop hook lives in LMC 8.4 R17.
4. **Whether Hexagon 688 is reachable** via NNAPI/delegates on this ROM (and at what speed).
5. **Licences:** FSRCNNX/ArtCNN shaders, any pretrained SR/interp models, SGSR1 (BSD-3) and CAS/FSR (MIT) headers.
6. **Whether 1080p60 recording is available** in the ported GCam on sweetin.
7. **Quality of block-matching MC on handheld footage with rolling shutter** — expect artifacts; the guards in §4.6 are designed for that but must be tuned on real clips.
8. **The "4K upload gets better treatment on platforms" claim** is community knowledge, not verified here.
9. **Topaz API terms/pricing and the exact model catalogue** — read the current docs before building on it.

---

## 14. References (read, don't copy blindly)

- Topaz Labs documentation and community: Video AI filters/models (Proteus, Iris, Nyx, Rhea, Artemis, Gaia, Theia, Themis; Apollo/Chronos/Aion), developer API video-models page, community reports on interpolation stutter and Nyx behaviour; third-party reviews with Proteus/Nyx timings.
- Google: "Real-Time Video Denoising on Mobile Phones" (Ehmann, Chu, Tsai — ICIP 2018); Pixel 8 Pro Video Boost explanations (Google blog/press).
- *Real-Time Video Super-Resolution on Smartphones with Deep Learning, Mobile AI 2021 Challenge: Report* (Ignatov et al.) — Adreno 650 / TFLite GPU runtimes.
- FastDVDnet (Tassano, Delon, Veit) — runtime on desktop GPU.
- RIFE / SVP RIFE hardware table; `rife-ncnn-vulkan` Android issue thread; ANVIL (accelerator-native video interpolation via codec motion-vector priors, 2026 arXiv).
- Qualcomm: Snapdragon 732G product page; WikiChip Snapdragon 7 table; Snapdragon Game Super Resolution (BSD-3); Adreno Motion Engine / AFME and Adreno Neural Fusion developer blogs.
- AMD FidelityFX CAS and FSR 1.0 (MIT); Anime4K (MIT) and FSRCNNX (mpv shader ecosystem).
- SuperImage (MNN + Real-ESRGAN on Android) benchmark; Real-ESRGAN / ncnn-vulkan projects.
- AI Benchmark (Ignatov et al.) — mobile delegate support tables (Hexagon 688 listed under the legacy Hexagon NN delegate).
