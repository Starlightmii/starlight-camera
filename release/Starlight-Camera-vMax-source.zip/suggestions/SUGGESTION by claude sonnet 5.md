# SUGGESTION.md — Starlight Camera vMax (LMC 8.4 R17 → sweetin + low-end devices)

**Audience:** the subagent that owns the APK patching / `classes4.dex` code.
**Scope:** answers Q1–Q21 of `PROBLEM_STATEMENT.md`, corrects wrong assumptions, and gives a fix order.
**How to read it:** §0 is the fix order. Every question has a short **Answer** first, then the detail. Code here is a *reference sketch* — compile-check it, do not paste blindly.

Confidence tags used below:

- **[known]** — documented platform behaviour or standard practice (AOSP CTS / grafika / Android docs).
- **[likely]** — strong inference from the symptoms; cheap to confirm.
- **[guess]** — estimate; measure before relying on it.
- **VERIFY** — must be tested on the real device (I cannot run it).

---

## 0. Executive summary

### 0.1 What is probably going wrong (symptom → cause)

| Symptom | Most probable cause | Conf. | How to prove it in 10 minutes |
|---|---|---|---|
| 0-byte output | `MediaMuxer` was constructed (file created/truncated) but `start()` never ran — the encoder never produced an output format because no frame reached it — or the process died first | [likely] | Log `muxStarted`, `framesRendered`, `framesEncoded` at job end |
| 3,232-byte output | Muxer *did* start and stop, but with **zero or ~1 sample**: the encoder emitted only format/CSD then EOS. The size is what a header-only MP4 looks like. The frame loop exited early (exception swallowed by a broad `catch`, or loop condition false) and fell through to "finalize" | [likely] | Same counters; add `Log.e(TAG, "...", t)` + **rethrow** in every catch |
| `frames=91` for a 1.47 s / 34-frame clip | 91 frames ÷ 24 fps = **3.79 s**, i.e. the duration the code used was not this clip's *video-track* duration (see §2.4). Most likely a different clip, or a container duration longer than the video track | [likely] | Log source URI, container duration, per-track durations, `VIDEO_FRAME_COUNT` in the same line |
| Camera ANR "5000 ms for MotionEvent" | The **camera process main thread** was blocked/starved ≥ 5 s. Candidates: heavy work or a blocking wait (`join`, `latch.await`, `Future.get`, `synchronized` shared with the worker, `eglSwapBuffers`/`dequeue*` with infinite timeout) on the main thread; or the periodic "re-apply touch interceptor" runnable; or severe memory pressure (4 × 33 MB allocations per frame) | [likely] but unproven | Pull the ANR trace via `ApplicationExitInfo` / bugreport (§7) and read the `"main"` thread stack |
| "CPU maxed, GPU barely used" | In every old path the time is on the CPU: `getFrameAtTime` (random-access decode + CPU YUV→RGB), RenderScript falling back to CPU, Java `fillYuv()` loops over 8.3 M pixels, 33 MB array churn | [known] | `top -H` per-thread CPU while running |
| Buffer path worked, GL-FBO path regressed | Not one bug — the FBO path adds 4 large per-frame allocations (OOM risk), thread-affinity of EGL, incomplete-texture/FBO pitfalls, and `glReadPixels` stalls. The tiny files are the *symptom of an early exit*, not of GL itself (§2.5) | [likely] | Add counters + GL error checks (§2.5) |

### 0.2 Fix order

**P0 — blockers (do these first, in this order)**

1. **Replace `MediaMetadataRetriever.getFrameAtTime()` with a real transcode pipeline:** `MediaExtractor → MediaCodec decoder → SurfaceTexture (OES) → GL → MediaCodec encoder input Surface → MediaMuxer`, one worker thread, source PTS preserved (§2.3).
2. **Make failure loud and self-cleaning:** per-stage frame counters, `framesEncoded == framesRendered` check, delete the output if it fails, never swallow `Throwable` (§2.5, §5).
3. **Nothing blocks the main thread; no unbounded waits anywhere;** add a stall watchdog (§3.3).
4. **EGL config exactly as CTS does it** (RGB888 + `EGL_RECORDABLE_ANDROID` + ES2, window surface); drop the PBUFFER bit from the encoder config; assert a context is current on the worker thread (§2.7).
5. **Save through MediaStore with `IS_PENDING=1`** (or hidden temp file + rename), publish only after validation (§5).
6. **Instrument for post-mortem:** `ApplicationExitInfo` logger + file log in `getExternalFilesDir` (§7).

**P1**

7. Interleave audio in the same loop (§2.8); handle rotation with `setOrientationHint` (§2.3).
8. Capability probe + "configure ladder" for encoder (needed for potato devices) (§7.2).
9. Low-priority GL context (`EGL_IMG_context_priority`), thermal-aware pacing (§3.2).
10. Foreground service with progress notification (§3.4).

**P2**

11. Shader upgrade: true Catmull-Rom (9 taps) + anti-ringing + gentle luma-only sharpen; drop the contrast stretch for video (§4).
12. Rainbow bar rewrite (no per-frame allocation, anchored to real layout, notification fallback) (§6.3).
13. Thumbnail opener via the intent builder / `startActivity` choke point instead of a global touch interceptor (§6.1).

**P3**

14. Separate `:sr` process (needs an `Application` guard — §3.3).
15. Photo path tiling + memory budget (§8).
16. Optional ML for stills only (§4.2).

### 0.3 Assumptions in the problem statement that are wrong or risky

1. **"Frame count = min(720, duration × fps)" — wrong approach.** A transcoder is driven by the decoder reaching EOS, not by metadata arithmetic. Metadata is for the progress bar only.
2. **`getFrameAtTime()` is not a transcoding API.** It is a random-access thumbnail API. With the default `OPTION_CLOSEST_SYNC` it returns the nearest **keyframe**, so a 1.5 s clip with a 1 s GOP yields 2 distinct images repeated; with `OPTION_CLOSEST` it re-decodes from the previous keyframe on every call (O(GOP) work per frame). Both explain high CPU; the first also explains wrong-looking output.
3. **"Always 24 fps" is unnecessary and harmful.** With a real decoder you keep every source frame and its PTS (VFR preserved). Resampling 30→24 causes judder. Only decimate (e.g. 60→30) for performance reasons.
4. **"Maximum GPU use" is the wrong goal.** The goal is *throughput with minimal CPU and no UI jank*. A saturated GPU hurts the camera preview and the whole system. Budget the GPU (§3.2).
5. **"Render to `createInputSurface()` fixes CPU and ANR."** It fixes CPU. It only fixes ANR if the loop is off the main thread and drains the encoder every frame (otherwise `eglSwapBuffers` can block forever, §2.6).
6. **"Request `PBUFFER|WINDOW` in one config."** For the encoder surface use a window-only recordable config exactly like CTS; asking for extra surface bits can return no config or a non-recordable one (§2.7).
7. **"40–60 Mbps, maybe 100 Mbps" for H.264 4K.** The content is upscaled; there is no native-4K detail to preserve. ~30–40 Mbps VBR is visually transparent; 100 Mbps mostly stresses the encoder (§3.5).
8. **JPEG quality 100 / 40 MP.** q98 vs q100 is visually identical and ~1.5× smaller; 40 MP RGBA is 160 MB per buffer and will get a 3–4 GB phone killed (§8).
9. **"Android 13-based ColorOS 17 port".** If the *framework* is newer than the vendor blobs, framework behaviour (foreground-service rules, MediaProvider, background limits) follows the newer framework while codecs/EGL/Adreno follow the old vendor stack. Log `ro.build.version.sdk`, `ro.vendor.build.version.sdk`, `ro.product.first_api_level` and branch on `Build.VERSION.SDK_INT`. Everything below is written to work on API 28–37.

---

## 1. Ground rules (apply to every section)

1. **One owner thread for GL.** The EGL context is created, used and destroyed on the *same* worker thread. GL calls with no current context are silent no-ops on Android, and `glGetError()` returns 0 — so a context on the wrong thread looks like "GL works but produces nothing". At job start assert `EGL14.eglGetCurrentContext() != EGL14.EGL_NO_CONTEXT`.
2. **Every wait has a timeout; every loop has a watchdog.** No `dequeueInputBuffer(-1)`, no `Object.wait()` without a deadline, no `Thread.join()` without one.
3. **Never swallow.** `catch (Throwable t) { log; cleanup; rethrow/report }`. A job that produced 0 frames must report failure and delete its output.
4. **No per-frame allocation** of anything larger than a few KB. The surface pipeline needs none.
5. **Never `eglTerminate()` the default display inside the camera process.** GCam's own GL shares it. Destroy only *your* surface/context and call `eglReleaseThread()`.
6. **Don't process while the camera is recording or bursting** (hardware codec instances, Venus bandwidth and GPU are shared). Queue and start when idle.
7. **No feedback loop.** Your own output lands in `DCIM/Camera`; make sure the auto-upscaler never re-processes `Upscaled_*` (name prefix + a registry entry / `DESCRIPTION` column), and skip sources that are already ≥ target size or HDR.

---

## 2. Video pipeline (Q1–Q6)

### 2.1 Target architecture

```
                 worker thread "sr-video" (owns EGL/GL)               HandlerThread "sr-frame-cb"
 ┌────────────┐   ┌──────────────┐  Surface   ┌───────────────┐        (SurfaceTexture callbacks only)
 │MediaExtract│──▶│ MediaCodec   │───────────▶│ SurfaceTexture│──onFrameAvailable──▶ notify()
 │ (video)    │   │ HW decoder   │ release(   │  (OES texture)│
 └────────────┘   └──────────────┘  render)   └──────┬────────┘
                                                      │ updateTexImage + getTransformMatrix
                                       Pass 1: OES → RGBA8 FBO (source size, applies transform)
                                       Pass 2: FBO → Catmull-Rom/(SGSR1) + limiter + luma sharpen
                                                      │ into EGL window surface
                                                      ▼
 ┌────────────┐   ┌──────────────┐  Surface   ┌───────────────┐   samples   ┌────────────┐
 │MediaExtract│──────────────────────────────────────────────────────────▶│ MediaMuxer │
 │ (audio)    │   passthrough, interleaved by PTS                          │  (MP4)     │
 └────────────┘                    │ eglPresentationTimeANDROID(src PTS)   └─────▲──────┘
                                   ▼                                              │
                            ┌──────────────┐  encoded buffers (drain every frame) │
                            │ MediaCodec   │──────────────────────────────────────┘
                            │ HW encoder   │
                            └──────────────┘
```

Why two GL passes (instead of sampling the OES texture directly in the upscaler):

- `samplerExternalOES` fetches do YUV→RGB conversion **per fetch**; a 9-tap shader would do 9 conversions per output pixel. Pass 1 converts once per *source* pixel (2 MP) instead of per output tap (8.3 MP × 9).
- External samplers can't be used with `texelFetch`/offset helpers and only support LINEAR/NEAREST + CLAMP. A plain `sampler2D` has none of those limits.
- Pass 1 applies the `SurfaceTexture` transform matrix (flip/crop) in one place, so Pass 2 can use clean 0..1 coordinates.

### 2.2 Q1 — Abandon `getFrameAtTime()`? Most robust single-thread design?

**Answer: yes, abandon it entirely for video.** Use the pipeline above. It is the same architecture AOSP's CTS (`DecodeEditEncodeTest`, `ExtractDecodeEditEncodeMuxTest` with its `InputSurface`/`OutputSurface` helpers) and grafika use, so it is the one path every certified device is tested against [known]. Media3 `Transformer` (with a custom `GlShaderProgram` effect) is the same design wrapped in a hardened library — see §2.9.

Design rules for the single-thread loop:

1. **Order of creation (CTS order):** encoder `configure()` → `createInputSurface()` → create EGL window surface on it → `eglMakeCurrent` → `encoder.start()` → create OES texture + `SurfaceTexture` **in that same current context** → `decoder.configure(format, surface, null, 0)` → `decoder.start()`.
2. **`SurfaceTexture` callbacks on their own `HandlerThread`:** `st.setOnFrameAvailableListener(listener, handler)` (API 21+). If the callback lands on a looper that your worker is blocking, or on the busy main looper, you get deadlocks/latency. The worker waits on a lock with a deadline.
3. **Strict one-in/one-out per frame:** `releaseOutputBuffer(idx, true)` → wait for frame-available → `updateTexImage()` → draw → `eglPresentationTimeANDROID` → `eglSwapBuffers` → drain encoder. If you release several decoder buffers before calling `updateTexImage()`, the `SurfaceTexture` drops the older ones (frames silently lost — another way to get "wrong frame count").
4. **PTS:** decoder output `info.presentationTimeUs` is already in presentation order. Pass `pts * 1000` ns to `eglPresentationTimeANDROID`. Do **not** rebase to 0; keep the source timeline so audio stays in sync (§2.8). Enforce strictly increasing PTS (`if (pts <= last) pts = last + 1000` ns).
5. **Output format changes:** on `INFO_OUTPUT_FORMAT_CHANGED` (decoder) log the new format (`width/height`, `crop-*`, `color-standard`, `color-range`). The `SurfaceTexture` transform matrix already accounts for crop (e.g. 1088→1080 coded height), so size your intermediate FBO from the *display* size (`KEY_WIDTH/HEIGHT` of the track format, or crop-adjusted size from the output format).
6. **Rotation (recommended strategy B):** set `KEY_ROTATION` to `0` on the decoder format so frames stay in *coded* orientation, scale in coded orientation, and call `muxer.setOrientationHint(rotation)` **before** `muxer.start()`. Result: a 1080×1920 portrait clip stored as 1920×1080 + 90° tag becomes 3840×2160 + 90° tag. **VERIFY** on a rotated clip that the logged `getTransformMatrix()` has no 90° component on this vendor stack. (Strategy A — let the decoder rotate via `KEY_ROTATION`, size the encoder as the rotated size, no orientation hint — also works, but swaps width/height everywhere and is easier to get wrong.)
7. **Hardware codecs only:** pick the decoder/encoder explicitly with `MediaCodecList(REGULAR_CODECS)` and prefer `isHardwareAccelerated()` (API 29) / reject names starting with `c2.android.` or `OMX.google.` for the encoder. A software 4K encoder is useless on this device.
8. **Non-realtime hints:** set `KEY_PRIORITY = 1` (best-effort) on the encoder and decoder so the codec doesn't compete as a realtime session, and `KEY_OPERATING_RATE` high if you want maximum throughput. **VERIFY** the codec accepts them (log `getOutputFormat()`).
9. **Encoder gets its colour tags:** `KEY_COLOR_STANDARD=BT709`, `KEY_COLOR_RANGE=LIMITED`, `KEY_COLOR_TRANSFER=SDR_VIDEO` (API 24+) — or whatever the *source* format carries. Compare output `ffprobe` colour fields to the source.
10. **Disable B-frames** on the encoder (`KEY_MAX_B_FRAMES = 0`, API 29) so PTS is monotonic and the muxer needs no `ctts`.

### 2.3 Reference implementation (sketch)

```java
public final class SrVideoTranscoder {
    private static final String TAG = "StarlightVideoSR";
    private static final long POLL_US = 10_000;
    private static final long FRAME_WAIT_MS = 2_500;

    public interface Progress { void onProgress(float frac); }
    public static final class Result {
        public int decoded, rendered, encoded;
        public long firstPtsUs = -1, lastPtsUs = -1;
        public boolean audioCopied;
    }
    /** Output plan chosen by the Planner (§7.2). */
    public static final class Plan {
        public int outW, outH, fps, bitrate; public String mime = "video/avc";
        public float sharpen = 0.20f, sat = 1.0f; public int decimate = 1; // 2 = keep every 2nd frame
        public boolean lowPriorityGl = true;
    }

    private final Context ctx; private final Plan plan; private final Progress progress;
    private volatile boolean cancelled;
    private final Stall stall = new Stall(8_000);   // ms without any progress → abort

    // state shared by helpers
    private MediaCodec dec, enc; private MediaMuxer mux; private int vTrack = -1, aTrack = -1;
    private boolean muxStarted; private final MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
    private MediaExtractor ax; private ByteBuffer aBuf; private boolean audioDone;
    private final MediaCodec.BufferInfo abi = new MediaCodec.BufferInfo();
    private final Result r = new Result();
    private int rotation; private long frameDurUs = 41_667;

    public void cancel() { cancelled = true; }

    public Result run(Uri src, FileDescriptor outFd) throws Exception {
        MediaExtractor vx = null;
        EglWindowCore egl = null; DecoderOutput decOut = null; GlScaler gl = null; Surface encIn = null;
        try {
            // ---------- inspect (never trust container duration for counts) ----------
            vx = new MediaExtractor(); vx.setDataSource(ctx, src, null);
            int vt = firstTrack(vx, "video/");
            if (vt < 0) throw new IOException("no video track");
            MediaFormat vf = vx.getTrackFormat(vt); vx.selectTrack(vt);
            String vmime = vf.getString(MediaFormat.KEY_MIME);
            int srcW = vf.getInteger(MediaFormat.KEY_WIDTH), srcH = vf.getInteger(MediaFormat.KEY_HEIGHT);
            rotation = vf.containsKey(MediaFormat.KEY_ROTATION) ? vf.getInteger(MediaFormat.KEY_ROTATION) : 0;
            long vDurUs = vf.containsKey(MediaFormat.KEY_DURATION) ? vf.getLong(MediaFormat.KEY_DURATION) : -1; // VIDEO track only
            if (isHdr(vf)) throw new UnsupportedOperationException("HDR/10-bit source: skip");
            Log.i(TAG, "src=" + src + " " + srcW + "x" + srcH + " rot=" + rotation + " vDurUs=" + vDurUs
                    + " mime=" + vmime + " plan=" + plan.outW + "x" + plan.outH + "@" + plan.fps);

            // ---------- encoder (surface input) ----------
            MediaFormat ef = buildEncoderFormat(plan, vf);        // §3.5, with the "configure ladder" (§7.2)
            enc = createHwEncoder(plan.mime, ef);                 // configure(CONFIGURE_FLAG_ENCODE) inside
            encIn = enc.createInputSurface();                     // after configure, before start

            // ---------- EGL on the encoder surface, then start encoder (CTS order) ----------
            egl = new EglWindowCore(encIn, plan.lowPriorityGl);   // §2.7
            egl.makeCurrent();
            if (EGL14.eglGetCurrentContext() == EGL14.EGL_NO_CONTEXT) throw new IllegalStateException("no GL context");
            enc.start();

            // ---------- GL resources + decoder output ----------
            gl = new GlScaler(srcW, srcH, plan.outW, plan.outH, plan.sharpen, plan.sat); // FBO + 2 programs
            decOut = new DecoderOutput();                          // OES tex + SurfaceTexture + cb HandlerThread
            MediaFormat df = MediaFormat.createVideoFormat(vmime, srcW, srcH);
            copyCsd(vf, df);                                       // csd-0/1, etc. come from the track format
            df.setInteger(MediaFormat.KEY_ROTATION, 0);            // strategy B (§2.2 #6)
            df.setInteger(MediaFormat.KEY_PRIORITY, 1);
            dec = createHwDecoder(vmime);
            dec.configure(vf2(vf, df), decOut.surface, null, 0);   // easiest: reuse vf, then override KEY_ROTATION/PRIORITY
            dec.start();

            // ---------- audio ----------
            openAudio(src);                                        // fills ax/aBuf; null if no audio

            // ---------- main loop ----------
            boolean inDone = false, decDone = false; int idx = 0; long lastPts = -1;
            while (!decDone) {
                if (cancelled) throw new CancellationException();
                stall.check();

                // A) feed decoder
                if (!inDone) {
                    int ii = dec.dequeueInputBuffer(POLL_US);
                    if (ii >= 0) {
                        ByteBuffer ib = dec.getInputBuffer(ii);
                        int n = vx.readSampleData(ib, 0);
                        if (n < 0) { dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true; }
                        else { dec.queueInputBuffer(ii, 0, n, vx.getSampleTime(), 0); vx.advance(); }
                    }
                }
                // B) drain encoder BEFORE we can block in eglSwapBuffers
                drainEncoder(false);

                // C) decoded frame → GL → encoder surface
                int oi = dec.dequeueOutputBuffer(bi, POLL_US);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    Log.i(TAG, "decoder out format: " + dec.getOutputFormat());
                } else if (oi >= 0) {
                    boolean eos = (bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    boolean has = bi.size > 0;
                    boolean keep = has && (idx++ % plan.decimate == 0);
                    long pts = bi.presentationTimeUs;
                    dec.releaseOutputBuffer(oi, keep);             // render=true only when we will draw it
                    if (has) r.decoded++;
                    if (keep) {
                        decOut.awaitNewImage(FRAME_WAIT_MS);       // throws on timeout
                        decOut.updateTexImage();
                        gl.pass1(decOut.oesTex, decOut.stMatrix()); // OES → RGBA8 FBO (source size)
                        gl.pass2();                                 // FBO → window surface (output size)
                        if (pts <= lastPts) pts = lastPts + 1;      // strictly increasing
                        egl.setPresentationTimeNs(pts * 1000L);
                        egl.swapBuffers();                          // throws if EGL says context/surface lost
                        lastPts = pts; r.rendered++;
                        if (r.firstPtsUs < 0) r.firstPtsUs = pts;
                        stall.reset();
                        if (vDurUs > 0 && progress != null) progress.onProgress(Math.min(1f, pts / (float) vDurUs));
                        pumpAudio(pts + 500_000);                   // keep audio within 0.5 s of video
                    }
                    if (eos) { enc.signalEndOfInputStream(); decDone = true; }
                }
            }
            drainEncoder(true);                                    // until encoder EOS
            if (r.rendered == 0 || r.encoded == 0) throw new IllegalStateException("no frames produced");
            if (r.encoded < r.rendered - 1) throw new IllegalStateException("encoder lost frames " + r.encoded + "/" + r.rendered);
            pumpAudio(r.lastPtsUs + frameDurUs + 100_000);         // finish audio, clipped to video end
            mux.stop();                                            // only on success
            return r;
        } finally {
            quiet(() -> { if (dec != null) dec.stop(); }); quiet(() -> { if (dec != null) dec.release(); });
            quiet(() -> { if (enc != null) enc.stop(); });  quiet(() -> { if (enc != null) enc.release(); });
            if (gl != null) quiet(gl::release);
            if (decOut != null) quiet(decOut::release);            // SurfaceTexture, Surface, OES tex, cb thread
            if (egl != null) quiet(egl::release);                  // window surface, context; NOT eglTerminate
            if (encIn != null) quiet(encIn::release);
            quiet(() -> { if (mux != null) mux.release(); });
            quiet(() -> { if (vx != null) vx.release(); });  quiet(() -> { if (ax != null) ax.release(); });
        }
    }

    private void drainEncoder(boolean untilEos) {
        while (true) {
            int ix = enc.dequeueOutputBuffer(bi, untilEos ? POLL_US : 0);
            if (ix == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!untilEos) return;
                stall.check();                                     // EOS must arrive within the stall budget
            } else if (ix == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (muxStarted) throw new IllegalStateException("encoder format changed twice");
                startMuxer(enc.getOutputFormat());                 // adds video (+ audio) tracks, setOrientationHint, start()
            } else if (ix >= 0) {
                ByteBuffer b = enc.getOutputBuffer(ix);
                if ((bi.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) bi.size = 0; // muxer takes CSD from the format
                if (bi.size > 0) {
                    if (!muxStarted) throw new IllegalStateException("sample before muxer start");
                    b.position(bi.offset); b.limit(bi.offset + bi.size);
                    mux.writeSampleData(vTrack, b, bi);
                    r.encoded++; r.lastPtsUs = bi.presentationTimeUs; stall.reset();
                }
                enc.releaseOutputBuffer(ix, false);
                if ((bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return;
            }
        }
    }
}
```

Support classes you need (all small; CTS/grafika have reference versions):

- `EglWindowCore` — §2.7.
- `DecoderOutput` — `glGenTextures` + `GL_TEXTURE_EXTERNAL_OES` (LINEAR, CLAMP_TO_EDGE), `new SurfaceTexture(tex)`, `setOnFrameAvailableListener(l, new Handler(cbThread.getLooper()))`, `awaitNewImage(ms)` (lock + deadline, resets the flag), `updateTexImage()`, `stMatrix()` (= `getTransformMatrix`), `release()`.
- `GlScaler` — RGBA8 FBO (source size) with `glCheckFramebufferStatus == GL_FRAMEBUFFER_COMPLETE` asserted, Pass-1 program (OES → FBO), Pass-2 program (§4.1), full-screen quad VBO.
- `Stall` — `check()` throws if `now - lastProgress > budget`; `reset()` updates it. A **watchdog thread** may also call `cancel()` and `enc.release()` if the worker is stuck inside `eglSwapBuffers` (releasing the encoder abandons its input surface, which makes the swap fail and lets the worker unwind) — **VERIFY** on this device.
- `startMuxer(MediaFormat)` — `vTrack = mux.addTrack(fmt)`; if audio exists `aTrack = mux.addTrack(audioFormat)`; `mux.setOrientationHint(rotation)`; `mux.start()`; `muxStarted = true`.
- `mux = new MediaMuxer(outFd, MUXER_OUTPUT_MPEG_4)` is created before the loop; the FD must be **opened `"rw"`** (MPEG-4 muxing needs read + seek).

Per-job `StrictMode`/threading rules: run the job on a `HandlerThread`/single-thread executor named `sr-video`; never call `run()` from the main thread; report progress to the UI with a `Handler(Looper.getMainLooper()).post` that coalesces (at most ~2 updates/s).

### 2.4 Q2 — Why 91 frames for a 1.47 s / 34-frame source?

**Answer:** The arithmetic only allows one conclusion: `frameCount = durationUs × fps / 1e6` for 1.47 s at 24 fps is **35**, not 91. To get 91 the duration fed to the formula must have been ≈ **3.79 s** (or the fps ≈ 62). So the value did not come from *this clip's video-track duration*. I cannot tell which of these happened from the statement, in descending likelihood:

1. **The log line and the `ffprobe` were for different files** (e.g. the auto-processor picked the newest video, a 3.8 s test clip). Fix the log: print the URI/path, size and all durations on the same line.
2. **Container duration ≠ video-track duration.** `MediaMetadataRetriever.METADATA_KEY_DURATION` is the container duration, which is the longest track — audio can run longer than video, and edit lists can shift things. `ffprobe` *stream* duration (video) vs *format* duration can differ. Use the **video track's** `MediaFormat.KEY_DURATION` from `MediaExtractor`.
3. **High-fps / slow-mo / time-lapse source** where capture fps ≠ playback fps (`METADATA_KEY_CAPTURE_FRAMERATE`).
4. **A second code path** (e.g. fps default of 60, or `max(..)` with another estimate) feeding the same variable.

**Correct approach (no frame count needed):**

- Drive the loop by decoder EOS. Count `decoded`, `rendered`, `encoded`.
- Progress = `currentPts / videoTrackDurationUs` (clamped 0..1). If the track has no duration, use `METADATA_KEY_VIDEO_FRAME_COUNT` (API 28+) or indeterminate progress.
- Validate afterwards: `encoded == rendered` (±1), and `(lastPts − firstPts) ≈ (n−1) × avgFrameDuration`.
- Debug aids for this exact question: log `vf` (full track format), `METADATA_KEY_DURATION`, `METADATA_KEY_VIDEO_FRAME_COUNT`, `METADATA_KEY_CAPTURE_FRAMERATE`, and the first/last 3 sample times from the extractor.

### 2.5 Q3 — Why did FBO + `glReadPixels` + `fillYuv()` give 3,232-byte files?

**Answer:** Two layers.

**Layer 1 — mechanism.** A ~3 KB MP4 is a header with no real samples. `MediaMuxer` only produces that if the encoder gave a format (+ CSD) and then EOS with ≤ 1 sample, i.e. the loop exited without feeding frames and the code still ran "finalize". The most common way that happens is a `try { … } catch (Throwable) { /* ignore */ }` (or a `break` on failure) around the frame loop, followed by `signalEndOfInputStream()`/`muxer.stop()` anyway. The 0-byte files are the case where the muxer was never started (or the process died before `stop()`).

**Layer 2 — root causes of the early exit in the FBO/buffer path, ranked:**

1. **Memory/OOM** [likely]. Per 4K frame: `ByteBuffer.allocateDirect(33 MB)` + `Bitmap` 33 MB + `int[]` 33 MB (in `fillYuv`) + the decoded source bitmap. That is 130+ MB of churn per frame. `OutOfMemoryError` ("Direct buffer memory" / "Failed to allocate") caught as `Throwable` → loop exit → header-only file.
2. **EGL context not current on the worker thread** [likely if `StarlightGL` is a long-lived singleton created elsewhere]. All GL calls become silent no-ops, `glGetError()` returns 0, `glReadPixels` leaves the buffer untouched. You usually get black/garbage rather than tiny files, *unless* a later step (`copyPixelsFromBuffer`, null `Bitmap`) throws.
3. **Incomplete texture** (ES2 NPOT rule). A 1920×1080 or 1080×1920 texture is NPOT; it is *complete* in ES2 only if `MIN_FILTER` is `LINEAR`/`NEAREST` (not the default `NEAREST_MIPMAP_LINEAR`) and `WRAP_S/T = CLAMP_TO_EDGE`. Otherwise sampling returns black with **no GL error**. Both `GLUtils.texImage2D` and `texSubImage2D` leave default parameters unchanged.
4. **FBO incomplete** at 3840×2160 or bound to a texture with undefined contents → `GL_INVALID_FRAMEBUFFER_OPERATION` on `glReadPixels` (returns zeros). Always assert `glCheckFramebufferStatus`.
5. **`getInputImage()` returned null or planes mismatched** [known pitfall]. On Qualcomm the encoder input is often NV12 semi-planar (U/V `pixelStride == 2`, interleaved/overlapping buffers) with stride and slice-height aligned (e.g. 2160→2176). `fillYuv` that assumes `rowStride == width` or planar I420 throws or writes garbage.
6. **`GLUtils.texImage2D` with a HARDWARE or recycled Bitmap** → exception. Source bitmaps must be `ARGB_8888` software.
7. **Encoder starvation** — in buffer mode `dequeueInputBuffer` timeouts treated as "stop".
8. **`glReadPixels` format** — only `GL_RGBA/GL_UNSIGNED_BYTE` is guaranteed for RGBA8 FBOs; `GL_BGRA` etc. are not.

**Triage in 10 minutes (do this even though P0 replaces the path):**

```java
final class GlDbg {
    static void check(String where) {
        int e;
        while ((e = GLES20.glGetError()) != GLES20.GL_NO_ERROR) Log.e("StarlightGL", where + " glError=0x" + Integer.toHexString(e));
        int ee = EGL14.eglGetError();
        if (ee != EGL14.EGL_SUCCESS) Log.e("StarlightGL", where + " eglError=0x" + Integer.toHexString(ee));
    }
}
// After: texImage2D, FBO attach (+ glCheckFramebufferStatus), draw, glReadPixels.
// And at job end, always one line:
Log.i(TAG, "job end: decoded=" + decoded + " rendered=" + rendered + " encoded=" + encoded
        + " muxStarted=" + muxStarted + " heapFree=" + (rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())));
```

If you keep any buffer-mode fallback (you should, for devices whose encoder rejects `COLOR_FormatSurface`): allocate **once** (reuse the `ByteBuffer`, never allocate `int[]`), do RGB→YUV **in a GL shader** (render NV12 planes into a single-channel + two-channel FBO, or use the encoder's `Image` planes with `libyuv`-style loops in native code). Java per-pixel loops over 8.3 MP are never acceptable.

### 2.6 Q4 — Is the encoder input surface the right fix? Lifecycle review

**Answer:** Yes for CPU and memory; it removes `glReadPixels`, `fillYuv` and all large buffers. It is only an ANR fix if (a) the loop is off the main thread, (b) the encoder is drained every frame, (c) nothing waits without a deadline.

Your lifecycle is correct in spirit. The order I recommend (CTS order, §2.2 #1):

1. `enc.configure(fmt, null, null, CONFIGURE_FLAG_ENCODE)` — with `KEY_COLOR_FORMAT = COLOR_FormatSurface`.
2. `Surface s = enc.createInputSurface()` (only valid between `configure` and `start`).
3. `eglCreateWindowSurface(dpy, cfg, s, {EGL_NONE}, 0)` → `eglMakeCurrent` → `eglSwapInterval(dpy, 0)`.
4. `enc.start()`.
5. Per frame: draw → `eglPresentationTimeANDROID(dpy, surf, ptsNs)` → `eglSwapBuffers`. **PTS must be set before every swap.**
6. After the last frame: `enc.signalEndOfInputStream()` (do **not** also call `queueInputBuffer`), then drain until `BUFFER_FLAG_END_OF_STREAM`.
7. Teardown: `enc.stop()` → `enc.release()` → destroy EGL surface → `s.release()` → destroy context. Don't touch the Surface after `enc.release()`.

**Mistakes that commonly break this (Adreno and otherwise):**

- **Not draining while swapping.** `eglSwapBuffers` calls `dequeueBuffer` on the encoder's BufferQueue. If the encoder's output buffers are full because you haven't drained, the swap blocks forever. That is a classic "hang → ANR". Drain (non-blocking, until `TRY_AGAIN_LATER`) at least once per frame *before* the swap.
- **Releasing several decoder buffers before `updateTexImage()`** → dropped frames (§2.2 #3).
- **EGL context current on a different thread** from the one that draws.
- **Calling `createInputSurface()` before `configure()` or after `start()`** → `IllegalStateException`.
- **Writing `BUFFER_FLAG_CODEC_CONFIG` buffers to the muxer.** Skip them; the muxer gets CSD from `getOutputFormat()`.
- **Adding the muxer track before `INFO_OUTPUT_FORMAT_CHANGED`**, or twice.
- **Non-monotonic PTS** (duplicate PTS from broken VFR sources) → rate-control confusion / dropped frames. Fix up with +1 µs as shown.
- **Odd or unaligned output size.** Use `VideoCapabilities.getWidthAlignment()/getHeightAlignment()` and `isSizeSupported()`; width/height must be even at minimum.
- **Missing `glViewport(0,0,outW,outH)`** after `makeCurrent` to the new surface.
- **Using `eglTerminate`** on the shared default display (§1 #5).
- **Treating `eglSwapBuffers() == false` as ignorable.** `EGL_CONTEXT_LOST` / `EGL_BAD_SURFACE` means the job is dead: abort, delete output, retry once at a lower tier.

### 2.7 Q5 — EGL config for the encoder window surface

**Answer:** Yes, **always request `EGL_RECORDABLE_ANDROID` (0x3142) = 1**. Adreno is lenient about it, many other vendors (Exynos, MediaTek, older Mali) are not, and "potato devices" are exactly those. Do **not** put `EGL_PBUFFER_BIT` in the same request.

CTS' `InputSurface` uses: RGB 8-8-8 (no alpha), `EGL_RENDERABLE_TYPE = EGL_OPENGL_ES2_BIT`, `EGL_RECORDABLE_ANDROID = 1`, no explicit surface-type mask (default = window), ES2 context. That is the one config every certified device supports for encoder surfaces — start there.

```java
final class EglWindowCore {
    private static final int EGL_RECORDABLE_ANDROID = 0x3142;
    private static final int EGL_CONTEXT_PRIORITY_LEVEL_IMG = 0x3100;
    private static final int EGL_CONTEXT_PRIORITY_LOW_IMG   = 0x3103;
    EGLDisplay dpy; EGLContext ctx = EGL14.EGL_NO_CONTEXT; EGLSurface surf = EGL14.EGL_NO_SURFACE; EGLConfig cfg;

    EglWindowCore(Surface encoderInput, boolean lowPriority) {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        if (dpy == EGL14.EGL_NO_DISPLAY) throw new IllegalStateException("no display");
        int[] v = new int[2];
        if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) throw new IllegalStateException("eglInitialize");
        int[] attrs = {
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE };
        EGLConfig[] c = new EGLConfig[1]; int[] n = new int[1];
        if (!EGL14.eglChooseConfig(dpy, attrs, 0, c, 0, 1, n, 0) || n[0] <= 0)
            throw new IllegalStateException("no RGB888+recordable ES2 config");   // check n[0], not just the boolean
        cfg = c[0];

        String ext = EGL14.eglQueryString(dpy, EGL14.EGL_EXTENSIONS);
        boolean prio = lowPriority && ext != null && ext.contains("EGL_IMG_context_priority");
        int[] ca = prio
            ? new int[]{EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL_CONTEXT_PRIORITY_LEVEL_IMG, EGL_CONTEXT_PRIORITY_LOW_IMG, EGL14.EGL_NONE}
            : new int[]{EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE};
        ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT, ca, 0);
        if (ctx == EGL14.EGL_NO_CONTEXT && prio)   // priority is only a hint; some drivers refuse it
            ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT, new int[]{EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE}, 0);
        if (ctx == EGL14.EGL_NO_CONTEXT) throw new IllegalStateException("eglCreateContext 0x" + Integer.toHexString(EGL14.eglGetError()));

        surf = EGL14.eglCreateWindowSurface(dpy, cfg, encoderInput, new int[]{EGL14.EGL_NONE}, 0);
        if (surf == EGL14.EGL_NO_SURFACE) throw new IllegalStateException("eglCreateWindowSurface 0x" + Integer.toHexString(EGL14.eglGetError()));
    }
    void makeCurrent() {
        if (!EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) throw new IllegalStateException("eglMakeCurrent");
        EGL14.eglSwapInterval(dpy, 0);      // no vsync pacing for a non-display surface
    }
    void setPresentationTimeNs(long ns) { EGLExt.eglPresentationTimeANDROID(dpy, surf, ns); }
    void swapBuffers() { if (!EGL14.eglSwapBuffers(dpy, surf)) throw new IllegalStateException("swap 0x" + Integer.toHexString(EGL14.eglGetError())); }
    void release() {
        EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
        if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf);
        if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx);
        EGL14.eglReleaseThread();           // do NOT eglTerminate the shared default display
    }
}
```

Notes:

- **RGB888 vs RGBA8888:** both work; CTS uses no alpha. If a vendor has no recordable RGB888-without-alpha config, retry with `EGL_ALPHA_SIZE=8`. Write an `eglChooseConfig` *ladder* (CTS style → +alpha → ES3 bit) and log which one was chosen.
- **Photos (offscreen) use a different config:** `EGL_SURFACE_TYPE = EGL_PBUFFER_BIT`, ES2/ES3, a 1×1 pbuffer to make current, and render into FBOs. A single context can be shared if the configs are compatible, but keep them separate for clarity.
- `EGL_IMG_context_priority` is a hint; query `EGL_CONTEXT_PRIORITY_LEVEL_IMG` via `eglQueryContext` after creation to see what you actually got and log it. AOSP's own GL wallpaper requests a LOW-priority context the same way (with an extension check) so other work can pre-empt it.
- Optional profiling: `GL_EXT_disjoint_timer_query` (present on Adreno 6xx) gives real GPU milliseconds per pass; fall back to `glFinish()` timing in debug builds.

### 2.8 Q6 — Audio and A/V sync

**Answer:** Copying the source audio track *is* safe with an input-surface video encoder — audio is passthrough (no re-encode), so it is independent of the video path. What matters is (a) one shared timeline, (b) writing audio during the video pass instead of dumping it all afterwards, (c) clipping audio to the video end.

1. **Keep the source timeline.** Feed video to the encoder with the *source* PTS (not rebased to 0) and write audio samples with their *source* PTS. Both tracks are then on the same clock; the muxer (MPEG4Writer) records any start offset between tracks as an edit list. A/V sync is preserved even if audio starts at 0 and video starts at 33 ms.
2. **Add both tracks before `muxer.start()`.** The video format only exists after the encoder's first `INFO_OUTPUT_FORMAT_CHANGED`, so: wait for it → `addTrack(video)`, `addTrack(audio)`, `setOrientationHint`, `start()`.
3. **Interleave.** After each rendered video frame call `pumpAudio(videoPts + 500 ms)`: read audio samples from a second `MediaExtractor` (audio track only) while `getSampleTime() <= limit`. At the end call `pumpAudio(lastVideoPts + oneFrame + ~100 ms)`.
4. **Clip trailing audio.** If the source audio is longer than the video (a likely cause of the 91-frame mystery and of "video freezes while audio continues"), drop samples beyond the last video PTS + a frame. Otherwise the output *duration* becomes the audio length.
5. **Buffer size:** `max(64 KB, aFmt.getInteger(KEY_MAX_INPUT_SIZE))`; `readSampleData` throws if the buffer is too small.
6. **Flags:** map `SAMPLE_FLAG_SYNC` → `BUFFER_FLAG_KEY_FRAME` for each audio sample.
7. **Unsupported audio codec in MP4** (e.g. some source containers): fall back to re-encode AAC-LC via `MediaCodec` or drop audio with a clear log line — never silently produce a mute file.
8. **No audio track** must work: `openAudio()` returns without adding a track.

```java
private void pumpAudio(long limitUs) {
    if (ax == null || audioDone || !muxStarted) return;
    while (true) {
        long t = ax.getSampleTime();
        if (t < 0) { audioDone = true; return; }
        if (t > limitUs) return;
        aBuf.clear();
        int n = ax.readSampleData(aBuf, 0);
        if (n < 0) { audioDone = true; return; }
        abi.set(0, n, t, (ax.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0);
        mux.writeSampleData(aTrack, aBuf, abi);
        ax.advance(); r.audioCopied = true;
    }
}
```

### 2.9 Alternative: Media3 `Transformer`

If you can afford the extra size (Media3 `transformer` + `effect` + `common` + their deps, shrunk with R8/d8), `androidx.media3.transformer.Transformer` already implements decode → GL effect chain → encode with audio passthrough, progress, cancellation, rotation, VFR, HDR→SDR handling, encoder fallbacks and a lot of vendor-quirk workarounds. You write only the upscale shader as a custom GL effect/`GlShaderProgram` and add `Presentation` for the output size. It is the more robust option for "potato devices" long-term; the cost is APK size and build-pipeline complexity (your `apktool + javac → classes4.dex` flow would need d8 with the library jars). Pin an exact version and **verify API names against that version**. My recommendation: ship the §2.3 pipeline first (small, in your control), keep the Media3 route as a hardening option once the rest is stable.

---

## 3. GPU, CPU, performance (Q7–Q10)

### 3.1 Q7 — Best GPU strategy for Adreno 618

**Answer:**

- **Video:** pure surface path (no readback), GLES2 context is enough (ES2 + `GL_OES_EGL_image_external`). Two passes as in §2.1. Optionally request an ES3 context first and fall back to ES2; ES3 buys little for video.
- **Photos:** ES3 if available (PBOs, `glBlitFramebuffer`), ES2 fallback. Render **tiled** into a fixed-size FBO and read back tile by tile (§8). PBO double-buffering overlaps GPU tile *N+1* with CPU copy of tile *N* (~20–30 % faster) — an optimization, not a requirement.
- **RenderScript:** treat as removed. It is deprecated since API 31, runs CPU-only on most modern Qualcomm builds, and may not exist on a newer framework. Keep the CPU Lanczos as the *last* fallback only.
- **"GPU barely used / CPU maxed"** is explained by §0.1: all old paths were CPU-bound. The surface path moves decode and encode to fixed-function hardware, colour conversion to the GPU, and leaves the CPU almost idle (submit loop only). Expect the picture to invert.
- **Don't go Vulkan/compute.** Not worth it on a 6xx mid-range for a two-pass fragment pipeline; ES keeps potato-device compatibility.
- **Potato-GPU guard:** query `glGetShaderPrecisionFormat(GL_FRAGMENT_SHADER, GL_HIGH_FLOAT)`. If highp isn't supported in fragment shaders (some Mali-400 / Adreno 3xx class GPUs), the cubic shader degrades (mediump can't address half-texels past ~1024), so fall back to bilinear + CPU-free sharpen, or disable video SR.

### 3.2 GPU budget (instead of "maximum GPU")

- Create the context with **LOW priority** (§2.7) so the camera preview and UI can pre-empt.
- If the camera preview is visible while processing, cap the duty cycle: measure `t_frame` and sleep so GPU busy ≲ 50–60 % (cheap pacing: `sleep(max(0, k × t_frame))`).
- Check `PowerManager.getCurrentThermalStatus()` (API 29) every ~30 frames and `addThermalStatusListener`:
  - `LIGHT` → nothing; `MODERATE` → pace (sleep) and lower thread priority; `SEVERE` → pause until it drops (abort after a few minutes); `CRITICAL+` → abort cleanly, delete output, notify.
- `PowerManager.isPowerSaveMode()` or battery < 20 % unplugged → pause or drop a tier.

### 3.3 Q8 — Likely cause of the ANR; does `:sr` help?

**Answer:** An "Input dispatching timed out … MotionEvent" ANR means the **camera process's main thread** did not consume input for 5 s. GPU saturation alone does not do that. What does:

1. **A blocking call on the main thread** (most likely): `Thread.join`, `CountDownLatch.await`, `Future.get`, `Object.wait`, `synchronized` on a lock the worker holds during a long GL/codec step, `MediaCodec` calls with infinite timeouts, `eglSwapBuffers`/`updateTexImage` on the main thread, `MediaMetadataRetriever` on main.
2. **`SurfaceTexture` listener delivered on the main looper** while the main thread is the one waiting for it (deadlock) — or simply lots of callbacks hammering main. Fixed by the dedicated callback `HandlerThread` (§2.2 #2).
3. **The periodic "re-apply touch interceptor" runnable** walking the whole view tree on the main thread (and re-posting itself with a tiny delay), plus a rainbow `onDraw` that allocates a new `LinearGradient` every frame (GC churn).
4. **System-level starvation:** 130+ MB of churn per frame → GC storms, `lmkd`/swap I/O stalls that freeze everything in the process.
5. GPU contention can slow the camera's own preview rendering, but not by itself produce a 5 s input stall.

**What to do:** get the actual trace (§7.1) and read the `"main"` thread. Interpretation:

- `waiting to lock <0x…> held by thread N (sr-video)` → lock contention: remove the shared lock.
- Native frames in `eglSwapBuffers`/`dequeueBuffer`/`MediaCodec.native_dequeue*` → GL/codec on main.
- `Runnable` running your touch-hook/animation code → main-thread CPU loop.
- `Waiting`/`TimedWaiting` in `join`/`await` → blocking wait on main.

**Would a separate `:sr` process or a foreground service materially reduce ANR risk?**

- **Foreground service (in-process):** helps *survival* (the OS keeps the job alive when the user leaves the app; ColorOS is aggressive about killing background work) and gives a progress notification. It does **not** by itself fix an ANR; the main thread must be free regardless.
- **`:sr` process:** helps with *isolation* (own heap budget, a GPU hang / OOM / native crash takes down `:sr`, not the camera) and removes memory pressure from the camera process. It does not fix a main-thread block caused by the camera's own code. **Trap:** a second process runs the app's `Application.onCreate()` — in GCam that is a heavy init (native libs, DI graph, possibly camera-related setup). You must patch the `Application` class to return immediately when the process name ends with `:sr`. Otherwise `:sr` will itself crash or burn seconds of CPU on startup. Because of that, do this in **P3**, after the in-process FGS version works.
- Manifest for `:sr` (later): `<service android:name=".starlight.SrService" android:process=":sr" android:exported="false" android:foregroundServiceType="dataSync"/>`. Use a `Messenger` (no AIDL needed) for progress + a small state file as a crash-proof fallback.

### 3.4 Q10 — Thread priority, executor, foreground service, responsive UI

**Answer:**

- **Execution:** one dedicated worker thread (`HandlerThread` or single-thread executor), named `sr-video`, plus the tiny `sr-frame-cb` callback thread. No thread pool.
- **Thread priority:** do **not** blindly use `THREAD_PRIORITY_BACKGROUND`. In Android, priority ≥ `THREAD_PRIORITY_BACKGROUND` (10) moves the thread to the background cgroup (little cores, small CPU share) — it can slow the submit loop and make the job take 2× longer while saving nothing. Use `THREAD_PRIORITY_DEFAULT` (0) or `THREAD_PRIORITY_LESS_FAVORABLE` (+1…+9, which stays in the foreground group), and use pacing (§3.2) for thermals. Drop to `BACKGROUND` only when the device is `MODERATE`+ hot.
- **Foreground service:** yes — one FGS per job queue with a progress notification (`setOngoing`, `setOnlyAlertOnce(true)`, determinate `setProgress`, Cancel action). Manifest: `FOREGROUND_SERVICE` permission, `android:foregroundServiceType="dataSync"` (valid since API 29; if apktool's framework knows `mediaProcessing` on API 35+, you can add it, otherwise stay with `dataSync`), optionally `POST_NOTIFICATIONS` (API 33; the FGS still runs if denied).
  - Android 12+ restricts *starting* an FGS from the background. Start it from the visible camera UI when the video is saved. Wrap `startForegroundService` in try/catch (`ForegroundServiceStartNotAllowedException` on newer frameworks) and fall back to "queue; start when the app returns to foreground".
  - ColorOS may still kill the process: tell the user (once, in settings) to set the app to *Unrestricted* battery usage / allow auto-start. An FGS helps but isn't a guarantee on OEM ROMs.
- **UI responsiveness:** the worker never touches views. Progress goes through a coalesced main-thread post (≤ 2/s) to the rainbow bar, and through the notification. The camera's own `Choreographer` is untouched. Add a **main-thread heartbeat** in debug builds: post a runnable every 500 ms and log when the observed latency exceeds 1 s — that catches ANR precursors long before 5 s.

### 3.5 Q9 — Realistic targets, codec, bitrate, fps policy

**Answer (all numbers [guess] — replace with the calibration in §7.2):**

- **Real-time is not required.** This is an offline job; the question is "minutes per minute of video", not fps.
- Per-frame cost at 1080p→4K with the two-pass design: Pass 1 ≈ 2 M source pixels (trivial), Pass 2 = 8.3 M output pixels × ~9 bilinear fetches ≈ 75 M texture fetches/frame (≈ 1.8 G fetches/s at 24 fps). That is a significant but plausible fraction of an Adreno 618's texture throughput. Add the encoder's RGBA→NV12 conversion and 33 MB/frame of buffer write+read. My planning range is **roughly 0.25×–0.7× real-time at 2160p**, 0.6–1.2× at 1440p, ≥ 1× at 1080p, thermally limited after a minute or two. So a 30 s 4K clip likely takes ~1–2 min. **Measure it.**
- **Codec/format policy:**

| Output | Codec | Bitrate (VBR) | Notes |
|---|---|---|---|
| 2160p (2×, ≤ 1080p source) | H.264 High | **28–40 Mbps** (default 35) | `bitrate ≈ outW×outH×fps×0.17` → 33.8 Mbps at 4K24; clamp to `getBitrateRange()` |
| 1440p | H.264 High | 15–22 Mbps | fallback tier |
| 1080p | H.264 | 8–14 Mbps | low-end tier |
| any, "smaller files" option | HEVC Main | ×0.6–0.7 of the above | optional; compatibility (sharing/transcoding by other apps) is worse, and HEVC encoder quality varies across vendors |

  - **H.264 default** for compatibility and encoder stability. HEVC as an explicit user option.
  - Offer "Max quality" up to ~50 Mbps; above that I'd test but not default. Very high bitrate mostly stresses the encoder and storage; upscaled content has no extra detail to spend it on.
  - `KEY_BITRATE_MODE`: `BITRATE_MODE_VBR` (check `isBitrateModeSupported`); `BITRATE_MODE_CQ` only if reported supported (often not on Qualcomm AVC). `KEY_I_FRAME_INTERVAL = 1`. Profile High + the level chosen from `CodecCapabilities.profileLevels`.
- **FPS policy:** preserve the source frame rate and PTS (§0.3 #3). Set `KEY_FRAME_RATE` to the rounded average source fps. Decimate only for performance (e.g. 60→30 by keeping every 2nd frame; implemented as `plan.decimate`). Never force-resample 30→24.
- **Use capabilities, not constants:** `VideoCapabilities.areSizeAndRateSupported(w,h,fps)`, `getAchievableFrameRatesFor(w,h)` (API 23) / `getSupportedPerformancePoints()` (API 29), `getBitrateRange()`, alignments. If the HW encoder doesn't support 3840×2160, step down automatically (§7.2).

---

## 4. Upscaling algorithm and image quality (Q11–Q13)

### 4.1 Q11 — Is Catmull-Rom + edge-gated unsharp the right trade-off?

**Answer:** Yes as the *default* — if it is **real** Catmull-Rom. For this class of device the best cost/quality is:

1. **Default (all GPUs with highp fragment precision): 9-tap Catmull-Rom (bilinear-trick) + local min/max limiter (anti-ringing) + gentle luma-only, edge-gated sharpen** — shader below.
2. **Optional "Sharper" mode on Adreno / ES 3.x devices: Qualcomm Snapdragon Game Super Resolution 1 (SGSR1)** — a single-pass 12-tap Lanczos-like upscaler with adaptive sharpening, designed and tuned for Adreno's tiled architecture, BSD-3-Clause. Also **AMD FSR 1.0 (EASU + RCAS)**, MIT licensed, with mobile-optimized single-pass ports around. Keep license headers. **Caveat:** these were designed for rendered game frames. On noisy camera video their sharpening amplifies noise/compression artifacts; keep sharpness conservative (SGSR's default edge threshold is 8/255; start at the default or lower) and A/B against the Catmull-Rom path on real clips. Check the shader's GLSL ES version requirement (Adreno 618 supports ES 3.2).
3. **Separable two-pass** (horizontal then vertical) halves the fetch count (3+3 taps with the bilinear trick vs 9) at the cost of an intermediate 3840×1080 RGBA8 target (~16 MB). Do it only if profiling shows Pass 2 is the bottleneck.
4. **Lanczos-3 in a shader** costs more (36 taps unless separable) for ringing you then have to clamp; Catmull-Rom/EASU are better value on mobile.

#### Reference Pass-2 fragment shader (GLSL ES 1.00)

```glsl
precision highp float;                 // REQUIRED: mediump (fp16) cannot address half-texels past ~1024
uniform sampler2D uSrc;                // LINEAR, CLAMP_TO_EDGE (mandatory for NPOT in ES2)
uniform vec2  uSrcSize;                // e.g. (1920.0, 1080.0)
uniform float uSharpen;                // 0.0 .. ~0.35 (video default 0.20, photo 0.30)
uniform float uSat;                    // 1.00 video, ~1.03 photo
varying vec2 vTc;                      // 0..1 across the OUTPUT

vec3 tap(vec2 p) { return texture2D(uSrc, p / uSrcSize).rgb; }     // p in texel units, centres at +0.5

void main() {
    vec2 pos = vTc * uSrcSize;                       // output pixel centre → source texel coordinates
    vec2 t1  = floor(pos - 0.5) + 0.5;               // centre of the texel at/below pos
    vec2 f   = pos - t1;
    // Catmull-Rom weights
    vec2 w0  = f * (-0.5 + f * (1.0 - 0.5 * f));
    vec2 w1  = 1.0 + f * f * (-2.5 + 1.5 * f);
    vec2 w2  = f * (0.5 + f * (2.0 - 1.5 * f));
    vec2 w3  = f * f * (-0.5 + 0.5 * f);
    vec2 w12 = w1 + w2;                              // merge the two positive centre taps into one bilinear fetch
    vec2 o12 = w2 / w12;
    vec2 p0  = t1 - 1.0, p3 = t1 + 2.0, p12 = t1 + o12;

    vec3 tl = tap(vec2(p0.x,  p0.y )), tc = tap(vec2(p12.x, p0.y )), tr = tap(vec2(p3.x,  p0.y ));
    vec3 ml = tap(vec2(p0.x,  p12.y)), cc = tap(vec2(p12.x, p12.y)), mr = tap(vec2(p3.x,  p12.y));
    vec3 bl = tap(vec2(p0.x,  p3.y )), bc = tap(vec2(p12.x, p3.y )), br = tap(vec2(p3.x,  p3.y ));

    vec3 c = tl * (w0.x * w0.y)  + tc * (w12.x * w0.y)  + tr * (w3.x * w0.y)
           + ml * (w0.x * w12.y) + cc * (w12.x * w12.y) + mr * (w3.x * w12.y)
           + bl * (w0.x * w3.y)  + bc * (w12.x * w3.y)  + br * (w3.x * w3.y);

    // Anti-ringing: the negative lobes can overshoot; clamp to the local range of the cross taps
    vec3 lo = min(min(min(tc, ml), min(mr, bc)), cc);
    vec3 hi = max(max(max(tc, ml), max(mr, bc)), cc);
    c = clamp(c, lo, hi);

    // Luma-only, edge-gated sharpen using taps we already fetched (no extra fetches)
    const vec3 L709 = vec3(0.2126, 0.7152, 0.0722);
    float yC  = dot(c, L709);
    float yNb = dot(0.25 * (tc + ml + mr + bc), L709);
    float d   = yC - yNb;                                         // local detail
    float gate = smoothstep(0.004, 0.030, abs(d))                 // ignore noise-level detail
               * (1.0 - smoothstep(0.15, 0.40, abs(d)));          // spare hard edges (halo risk)
    c += uSharpen * gate * d;                                      // same delta on all channels → no colour fringing
    c = clamp(c, lo - 0.02, hi + 0.02);                           // small residual overshoot allowance

    float y = dot(c, L709);
    c = mix(vec3(y), c, uSat);
    gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
```

Why this shape: the 9 fetches are exactly the five "cross" taps plus four corners; the limiter and the sharpen both reuse them, so total fetch cost stays 9 per output pixel. Everything is stateless per frame → no temporal shimmer from the shader itself (gating uses `smoothstep`, never a hard threshold, so detail doesn't pop in and out between frames).

#### 4.2 ML super-resolution — realistic?

**Answer: not for video on this device, and only as an optional slow mode for stills.**

- A published on-device benchmark (SuperImage, MNN + Real-ESRGAN, Vulkan) reports **about 3 minutes** to turn one 1920×1080 image into 3840×2160 on a **Snapdragon 855** — a GPU roughly 1.5–2× faster than the Adreno 618. Video at 24 fps needs ~24 such frames per second. That is five orders of magnitude off.
- Tiny SR nets (FSRCNN/ESPCN-class) via the TFLite GPU delegate are cheaper, but 3×3 convolutions with 32 channels at 1080p cost tens of GFLOP per layer; I'd estimate 0.5–1 s per frame even for a 3-layer net **[guess]** — too slow for video, marginal for photos. The Hexagon DSP might help for int8 models via NNAPI **VERIFY**, but it is not accessible/stable on every ROM.
- Real-ESRGAN class models also invent texture (plastic skin, flicker across frames without temporal modelling), add 5–70 MB to the APK, and do nothing on potato devices.
- **Recommendation:** classical GPU for everything. If you want an "AI" mode: stills only, ≥ 6 GB RAM devices only, explicit user opt-in, tile-based, with a time estimate and cancel, and run it in the FGS.

### 4.3 Q12 — Is your bicubic shader correct? Edge cases

**I can't see the shader**, so here is what to check against the reference above:

1. **"Four cubic weights, four texels, `mix()`" is not bicubic** unless it is the 4-bilinear-fetch trick. That trick (GPU Gems 2) is exact only for **B-spline** weights (all positive) — which is a *blurring*, non-interpolating filter and looks soft for upscaling. For **Catmull-Rom** the outer weights are negative, so the pair-merge trick is exact only for the centre pair → **9 fetches** (or 5 if you drop the corner taps). If your weights are `w0..w3` positive and sum to 1, you have B-spline; if you merge (w0+w1) and (w2+w3) with Catmull-Rom weights you have an approximation with visible errors.
2. **Precision:** `precision highp float;` in the fragment shader (guard with `GL_FRAGMENT_PRECISION_HIGH`). `mediump` positions break above ~1024 texels.
3. **NPOT texture state (ES2):** `GL_LINEAR` min/mag, `GL_CLAMP_TO_EDGE` both axes, no mipmaps — otherwise the texture is incomplete and samples as black without any GL error.
4. **Sample alignment:** use `floor(pos − 0.5) + 0.5` and the **pixel-centre** varying; an off-by-half-texel error shows up as a diagonal shift and ringing on edges.
5. **Edge clamping:** `CLAMP_TO_EDGE` makes borders safe; check the 2-pixel border visually on a chart.
6. **Output size even and aligned** for the encoder; compute the sampling coordinate from `outW/outH` consistently (don't derive the scale from the rounded integer factor if you applied alignment cropping).

**Edge-case test list:** source smaller than 4×4; 1×N strips; odd dimensions (1081, 1919); 90°/270° rotated portrait clips; 180°; mirrored front-camera clips; crop-rectangle sources (1088→1080 coded); 4K→4K (skip, no upscale); photo readback at 4K+ (tile stitching seams, vertical flip from GL's bottom-left origin — fix by flipping in the vertex shader, not on the CPU); alpha premultiplication (force alpha = 1 on output).

### 4.4 Q13 — Colour matrix, saturation, contrast, sharpen for video

**Answer:** Your current look is too aggressive for video, and one part is plainly lossy.

- `rgb * 1.15 − 19.125/255` pivots at 0.5 (0.575 − 0.075 = 0.5, good) but its *endpoints*: output reaches 0 at input 0.0652 and 1 at input **0.9348**. Everything below 6.5 % and above 93.5 % of the range clips. Decoded video is full-range RGB 0–1 after YUV→RGB (legal 16–235 maps to 0–1), so you are **crushing shadows and blowing highlights** across the whole clip (sky gradients, specular highlights, dark scenes).
- Saturation `mix(luma, rgb, 1.15)` in gamma-encoded space is acceptable if mild, but 1.15 plus per-channel clipping shifts hue on already-saturated reds/blues and skin.
- Unsharp strength 0.35/0.45 *after* a 2× interpolation, with a radius defined in **output pixels**, either does nothing (radius 1 px on a 2-px-wide edge) or halos. And fixed-bitrate encoders spend bits on sharpened noise, so heavy sharpening can **reduce** final quality (blocking).

**Recommendations:**

- **Video default:** no contrast stretch, saturation 1.00–1.05, sharpen 0.15–0.25 (shader above), "Off" available. If you want contrast, use an endpoint-preserving curve (e.g. `c = mix(c, c*c*(3.0-2.0*c), 0.10)`), never a linear stretch.
- **Photos:** may use saturation ~1.03–1.06 and sharpen 0.25–0.35, still no linear contrast stretch; photos are sRGB/JPEG and the user can see clipping in the histogram.
- **Colour tags:** pass the *source* `KEY_COLOR_STANDARD/RANGE/TRANSFER` to the encoder; default BT.709 limited for ≥ 720p SDR. **HDR/10-bit sources (HLG/PQ/HEVC Main10):** skip processing (or pass through) — an 8-bit SDR shader on HDR frames produces washed-out video.
- **Verify:** round-trip an SMPTE-bars + gray-ramp clip and compare with `ffmpeg -i in.mp4 -i out.mp4 -lavfi "scale=…,psnr"` after scaling, and check `ffprobe -show_streams` colour fields.

---

## 5. Save path, MediaStore, gallery visibility (Q14–Q16)

### 5.1 Q14 — Direct file + scan, or MediaStore?

**Answer:** Use **MediaStore with `IS_PENDING = 1`** as the primary route (API 29+), with "hidden temp file + atomic rename + scan" as the fallback (ported ROMs may have quirks). Reasons: no duplicate rows, correct ownership, invisible until finished, automatic expiry of abandoned items.

```java
ContentResolver cr = ctx.getContentResolver();
Uri coll = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);   // API 29+
ContentValues v = new ContentValues();
v.put(MediaStore.MediaColumns.DISPLAY_NAME, "Upscaled_" + baseName + ".mp4");
v.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
v.put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera");
v.put(MediaStore.MediaColumns.IS_PENDING, 1);
v.put(MediaStore.MediaColumns.DATE_EXPIRES, (System.currentTimeMillis() + DateUtils.DAY_IN_MILLIS) / 1000); // abandon → auto-purge
v.put(MediaStore.Video.Media.DATE_TAKEN, sourceDateTakenMs);     // optional: sits next to the original in the timeline
Uri uri = cr.insert(coll, v);
ParcelFileDescriptor pfd = cr.openFileDescriptor(uri, "rw");     // "rw", not "w"
// … run SrVideoTranscoder with pfd.getFileDescriptor() …
// on success, AFTER muxer.stop()/release():
validate(uri);                                                   // §5.2
pfd.close();
ContentValues done = new ContentValues(); done.put(MediaStore.MediaColumns.IS_PENDING, 0);
cr.update(uri, done, null, null);                                // publishes; MediaProvider extracts metadata
// on any failure:
cr.delete(uri, null, null);
```

- **No `MediaScannerConnection` needed** on this route; calling it on the same path is harmless (same row, no duplicate), but pointless.
- **Duplicates** happen when you both `insert()` a row *and* write a file with a different name/path, or when two jobs choose the same display name (MediaStore then appends " (1)"). Generate unique names (`<source-base>_SR`, or timestamped) and keep one code path per job.
- **Ownership:** rows are owned by the inserting package (`OWNER_PACKAGE_NAME`). Re-signing/reinstalling the patched APK with a different key or after uninstall can orphan old rows (you can no longer modify/delete them without user consent). Keep a stable signing key.
- **Fallback (file route):** write `DCIM/Camera/.starlight_<jobId>.tmp` (dot-prefixed files are ignored by the scanner), finalize the muxer, validate, `File.renameTo()` to the final name (same directory ⇒ atomic), then `MediaScannerConnection.scanFile(ctx, new String[]{path}, new String[]{"video/mp4"}, cb)` and use the returned `Uri`. On failure `File.delete()`.
- Declare nothing exotic: scoped storage permits creating your own media this way without `MANAGE_EXTERNAL_STORAGE`. For API 28 and below, the file route is the only one.
- **Test both routes on the actual ROM** — ColorOS Gallery keeps its own DB synchronized from MediaStore; check that the item appears, has the right thumbnail, duration, and date order.

### 5.2 Q15 — Temp file, atomic rename, no 0-byte / 3,232-byte litter

**Answer:** Yes — and the `IS_PENDING` route *is* that pattern. Rules:

1. **Never publish an unvalidated file.** Validation (cheap, ~tens of ms):
   - `MediaExtractor` opens it; has a video track; counts video samples ≥ `0.98 × rendered`;
   - `KEY_DURATION` within ±1 frame (±100 ms) of the source video track;
   - size > 64 KB (and > `bitrate × duration × 0.25 / 8`);
   - `MediaMetadataRetriever.getFrameAtTime(duration/2)` returns a non-black bitmap (optional, debug builds).
2. **On any failure:** delete the pending row / temp file immediately, record the reason in the log, show one notification ("Couldn't process this video").
3. **Kill-safety:** pending rows expire (we set 24 h; default is ~7 days) and are hidden from galleries meanwhile. At app start and at FGS start run `cleanupStale()`:
   - query our own pending rows (`QUERY_ARG_MATCH_PENDING = MATCH_ONLY` on API 30+, `MediaStore.setIncludePending(uri)` on 29) with `OWNER_PACKAGE_NAME = pkg` and name `LIKE 'Upscaled_%'`, older than 15 min, **and** no job currently running → delete;
   - file route: delete `.starlight_*.tmp` older than 1 h;
   - **heal existing litter:** delete our own published `Upscaled_*.mp4` with `SIZE < 64 KB` or `DURATION = 0`. For the files already on your test phone: `adb shell find /sdcard/DCIM/Camera -name 'Upscaled_*' -size -64k` then `rm` them (and let the scanner drop the rows).
4. **Storage pre-check:** estimated size = `bitrate × duration / 8 × 1.1`; require free space ≥ 1.5 × estimate (`StatFs` on the target volume) *before* starting. Re-check every ~10 s during long jobs; abort cleanly when < 100 MB remain.

### 5.3 Q16 — 30-second cap or full clips?

**Answer:** Replace the frame cap with a **budget**: process full clips with progress and cancel, but only when the projected cost is acceptable.

- After ~20 frames (skip the first 3 for warm-up) compute `msPerFrame` and project `totalMin`. Policy (defaults, user-tunable): auto-run if projected time ≤ 6× clip length and ≤ 10 min; otherwise ask once ("This will take ~N min. Process now / at 1080p / skip").
- Decide the tier **before** writing much (resolution can't change mid-stream): if the projection at 2160p is bad, **restart** the job at 1440p within the first ~5 % rather than switching mid-file.
- Long jobs run in the FGS (§3.4) with a Cancel action; thermal and storage checks per §3.2/§5.2; battery < 20 % unplugged → pause or defer ("only when charging" setting).
- Keep a *max length* setting (default maybe 2–3 min on mid-range, unlimited on flagship) as a safety rail, but expressed in seconds of source video, not frames.
- Never keep partial output: on cancel/failure delete it (don't leave truncated files that look valid).

---

## 6. Preview opener and UI (Q17–Q19)

### 6.1 Q17 — Safer hook than a global touch interceptor

**Answer:** Don't intercept touches globally. In order of preference:

1. **Patch the intent builder (best).** The thumbnail ultimately builds an `Intent` and calls `startActivity`. Find it in the smali: `grep -rn "com.google.android.apps.photos" smali*/`, `grep -rn "android.intent.action.VIEW\|com.android.camera.action.REVIEW" smali*/`. Change the target package/component (or insert a call to `StarlightOpener.rewrite(intent)`) at that single point. Zero runtime hooking, no tap stealing.
2. **Single choke point: override `startActivity(Intent)` / `startActivityForResult` in the main camera Activity class** (smali: add the method, call `StarlightOpener.rewrite(ctx, intent)`, then `invoke-super`). Rewrite only intents that GCam would send to Google Photos (package/component match) or generic `ACTION_VIEW` on a media URI from the thumbnail. Everything else is untouched.
3. **Wrap the thumbnail view's click** (find the view by resource id name via `getResources().getIdentifier`, or by walking from a known neighbour). Set the listener **once**, and re-apply only on a real signal (`ViewTreeObserver.OnGlobalLayoutListener` when the view's `hasOnClickListeners()` flips), never on a timer. Avoid reflection into `View.mListenerInfo`.
4. **Last resort: a transparent overlay** exactly over the thumbnail's rect (`getGlobalVisibleRect`, updated via `OnLayoutChangeListener`), `ACTION_UP` within touch slop triggers the open; it does **not** capture anything outside that rect, so shutter, mode switcher and preview gestures are untouched. Give it `contentDescription` ("Open gallery"), a ≥ 48 dp target, and implement `performClick()` so TalkBack and keyboard activation work.

Accessibility/predictability: single tap = open; long-press and drag unchanged; no activation on `ACTION_DOWN`; content description set; works with TalkBack and "remove animations".

### 6.2 Q18 — Which item to open; fallbacks; chooser

**Answer:** Open **the same item GCam would open** (the thumbnail's own URI), just in the user's preferred app. That keeps behaviour predictable ("the thumbnail shows X, tapping opens X"). Only if there is no URI, query MediaStore:

```java
// Latest visible capture, photos + videos together, scoped by path (NOT by bucket name):
Uri files = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
Bundle q = new Bundle();
q.putString(ContentResolver.QUERY_ARG_SQL_SELECTION,
    "(media_type IN (1,3)) AND relative_path LIKE ?");           // image=1, video=3
q.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, new String[]{"DCIM/Camera/%"});
q.putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, new String[]{MediaStore.MediaColumns.DATE_ADDED});
q.putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING);
q.putInt(ContentResolver.QUERY_ARG_LIMIT, 1);
```

- `BUCKET_DISPLAY_NAME = "Camera"` is ambiguous (any folder named Camera, other roots). Use `RELATIVE_PATH` (or `BUCKET_ID`). Pending (`IS_PENDING=1`) and trashed rows are already excluded by default.
- **Launch:** `ACTION_VIEW`, `setDataAndType(uri, mime)`, `FLAG_ACTIVITY_NEW_TASK | FLAG_GRANT_READ_URI_PERMISSION`, `setPackage(preferred)` (and a component only if you resolved it).
- **Fallback chain:** preferred app → implicit `ACTION_VIEW` (let the system's default/resolver decide) → Photos. Catch `ActivityNotFoundException` and `SecurityException`. When the preferred app is missing, show a short toast once and let the system chooser appear *once*; don't silently flip the user's preference.
- **Package visibility (Android 11+):** `PackageManager.resolveActivity()/queryIntentActivities()` return nothing for packages you can't see. Add to the manifest:
  ```xml
  <queries>
    <intent><action android:name="android.intent.action.VIEW"/><data android:mimeType="image/*"/></intent>
    <intent><action android:name="android.intent.action.VIEW"/><data android:mimeType="video/*"/></intent>
    <package android:name="com.google.android.apps.photos"/>
    <!-- plus the ColorOS gallery package name you find below -->
  </queries>
  ```
  Without it your "is the preferred app installed?" check lies, and the fallback fires wrongly.
- **Don't hard-code ColorOS class names.** I can't verify them for the ColorOS 17 port. Discover them on the device: `adb shell cmd package resolve-activity --brief -a android.intent.action.VIEW -t image/jpeg` and `... -t video/mp4`, and `adb shell pm list packages | grep -i gallery`. Store the user's choice (package + optional component) in settings and re-validate it at tap time.

### 6.3 Q19 — Rainbow bar: placement, animation, touches, background visibility

**Answer:** A lightweight `View` is fine; fix the *allocation*, the *anchoring* and the *foreground-only* limitation.

```java
final class RainbowBar extends View {
    private static final int[] C = {0xFFFF3B30,0xFFFF9500,0xFFFFCC00,0xFF34C759,0xFF00C7BE,0xFF007AFF,0xFFAF52DE,0xFFFF3B30}; // last == first → seamless
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix m = new Matrix();
    private LinearGradient g; private ValueAnimator anim;
    private float progress = -1f;                       // <0 = indeterminate

    RainbowBar(Context c) {
        super(c);
        setClickable(false); setFocusable(false);       // never takes touches
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
        setContentDescription("Processing video");
    }
    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        g = new LinearGradient(0, 0, w, 0, C, null, Shader.TileMode.REPEAT);    // built ONCE
        p.setShader(g);
    }
    void setProgress(float f) { progress = f; invalidate(); }
    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); start(); }
    @Override protected void onDetachedFromWindow() { stop(); super.onDetachedFromWindow(); }
    @Override protected void onVisibilityChanged(View v, int vis) { super.onVisibilityChanged(v, vis); if (vis == VISIBLE) start(); else stop(); }
    private void start() {
        if (anim != null || !isShown()) return;
        if (Build.VERSION.SDK_INT >= 26 && !ValueAnimator.areAnimatorsEnabled()) return;   // respect "remove animations"
        anim = ValueAnimator.ofFloat(0f, 1f); anim.setDuration(1600); anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> { m.setTranslate(getWidth() * (float) a.getAnimatedValue(), 0); if (g != null) g.setLocalMatrix(m); invalidate(); });
        anim.start();
    }
    private void stop() { if (anim != null) { anim.cancel(); anim = null; } }
    @Override protected void onDraw(Canvas c) {
        float w = getWidth() * (progress < 0 ? 1f : Math.max(0.02f, progress)), h = getHeight();
        c.drawRoundRect(0, 0, w, h, h / 2, h / 2, p);
    }
}
```

- **No per-frame allocation** (the old `LinearGradient` per draw caused GC churn on the main thread); animate a matrix on one shader. `ValueAnimator` is `Choreographer`-driven and stops when detached/hidden.
- **Anchoring below the mode labels across aspect ratios:** don't use a fixed `38 dp` bottom margin. Find the **mode-label container** (via resource id name in the decompiled `res/values/public.xml`/`ids.xml` — GCam usually keeps resource names — or `uiautomator dump`) and place the bar in the same parent aligned to that view's bottom plus a small gap, recomputed on `OnLayoutChangeListener`. Also apply `WindowInsets` (3-button vs gesture navigation differ). If the view can't be found, fall back to `bottom inset + 24 dp` and log it.
- **Touches:** `setClickable(false)`, no `onTouchEvent`; if you add it via `FrameLayout.addView`, give it a tiny height (4 dp) so even the hit rect is irrelevant.
- **Visible while the UI isn't foreground:** a view can't be. Use the **FGS notification** (determinate progress) as the background indicator, and let the bar re-attach and read state (Messenger/bound service or a state file polled at 2 Hz) when the camera returns to the foreground. Completion → notification with a "View" action that opens the output.
- **Accessibility:** announce completion with `announceForAccessibility`, keep a text content description, and show a static bar when animations are disabled.

---

## 7. Robustness, diagnostics, low-end policy (Q20–Q21)

### 7.1 Q20 — Diagnosing the ANR and process death without root

**Answer:** You can get almost everything without root. Order of usefulness:

**1. In-app, zero tooling — `ApplicationExitInfo` (API 30+).** On every cold start, read the history and write it to a file; for ANRs (and native crashes) the system hands your app its own stack trace:

```java
@RequiresApi(30)
static void dumpExitReasons(Context c) {
    ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
    for (ApplicationExitInfo i : am.getHistoricalProcessExitReasons(c.getPackageName(), 0, 5)) {
        StarlightLog.i("exit reason=" + i.getReason() + " status=" + i.getStatus() + " desc=" + i.getDescription()
                + " importance=" + i.getImportance() + " pss=" + i.getPss() + " ts=" + i.getTimestamp());
        if (i.getReason() == ApplicationExitInfo.REASON_ANR || i.getReason() == ApplicationExitInfo.REASON_CRASH_NATIVE) {
            try (InputStream in = i.getTraceInputStream()) { if (in != null) StarlightLog.saveTrace("exit-" + i.getTimestamp() + ".txt", in); }
            catch (IOException ignored) {}
        }
    }
}
```

Also write a rolling log file to `getExternalFilesDir(null)/starlight/` (readable with `adb pull /sdcard/Android/data/<pkg>/files/starlight/`) containing: job inputs, plan, codec names, EGL config chosen, counters, thermal status, free heap, exceptions with stack traces. Include `ro.build.version.sdk`, `ro.vendor.build.version.sdk`, `GL_RENDERER`, `GL_VERSION`, `GL_MAX_TEXTURE_SIZE`.

**2. adb, no root:**

```bash
# Why did the process die?
adb shell dumpsys activity exit-info com.google.android.GoogleCameraLMCR17
adb shell dumpsys activity lastanr
adb logcat -b events -d | grep -E "am_anr|am_proc_died|am_kill|am_low_memory"
adb logcat -b crash -d

# ANR / crash / tombstone records (shell can read DropBox)
adb shell dumpsys dropbox                                  # list tags & timestamps
adb shell dumpsys dropbox --print data_app_anr | tail -n 500
adb shell dumpsys dropbox --print data_app_crash
adb shell dumpsys dropbox --print SYSTEM_TOMBSTONE         # native crashes (also data_app_native_crash)

# Full picture incl. ANR traces (the bugreport zip contains /data/anr and a "VM TRACES AT LAST ANR" section)
adb bugreport starlight-bugreport.zip

# Live, filtered log while reproducing
adb logcat -c
adb logcat -v threadtime StarlightVideoSR:V StarlightGL:V MediaCodec:V CCodec:V Codec2Client:V ACodec:V \
  MPEG4Writer:V MediaMuxer:V SurfaceTexture:V BufferQueueProducer:V GLConsumer:V libEGL:V \
  AndroidRuntime:E DEBUG:V StrictMode:V ActivityManager:I *:S
```

**3. State dumps during/after a run:**

```bash
adb shell dumpsys media.resource_manager        # codec resource usage / "insufficient resources"
adb shell dumpsys media.codec                   # codec service state
adb shell dumpsys SurfaceFlinger | head -n 120
adb shell dumpsys gfxinfo com.google.android.GoogleCameraLMCR17
adb shell dumpsys meminfo com.google.android.GoogleCameraLMCR17
adb shell dumpsys thermalservice
adb shell "top -H -b -n 1 -p $(pidof com.google.android.GoogleCameraLMCR17)" | head -n 30   # per-thread CPU: name your threads!
# GPU load/frequency — often readable by shell, may be denied by SELinux on some ROMs:
adb shell cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage /sys/class/kgsl/kgsl-3d0/gpuclk
adb shell "for z in /sys/class/thermal/thermal_zone*/; do echo \$(cat \$z/type) \$(cat \$z/temp); done"
```

**4. Perfetto (works from API 29+ without root; strongest tool for jank/ANR/GPU):**

```bash
adb shell perfetto -o /data/misc/perfetto-traces/sr.pftrace -t 30s \
  sched freq idle am wm gfx view binder_driver hal dalvik camera input res memory
adb pull /data/misc/perfetto-traces/sr.pftrace && # open at https://ui.perfetto.dev
```

**5. Make the next ANR self-explanatory:** name every thread (`sr-video`, `sr-frame-cb`), enable `StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build())` in debug builds, and run the main-thread heartbeat (§3.4). For EGL/GL/codec failures log: chosen EGL config attributes, `eglQueryContext` priority, every `eglGetError`/`glGetError`, `MediaCodec.CodecException` (`getErrorCode()`, `isTransient()`, `isRecoverable()`, `getDiagnosticInfo()`), codec names, and `getOutputFormat()` of both codecs. Optional: `adb shell setprop debug.egl.trace error` (may be settable by `shell`; affects processes started afterwards) **VERIFY**.

`MediaCodec.CodecException` handling: `ERROR_INSUFFICIENT_RESOURCE (1100)` / `ERROR_RECLAIMED (1101)` mean another client (the camera's own recorder!) took the hardware — back off and retry once the camera is idle; other errors → abort + lower tier.

### 7.2 Q21 — Low-end fallback policy (automatic *and* user-selectable)

**Answer: both.** Default = **Auto** (capability probe + one-time calibration + runtime adaptation); the user can override any part. Never downgrade silently — say what happened in the completion notification ("Processed at 1080p: device was warm").

**Capability probe (once, cached; re-run after OS/app update):**

- Encoder/decoder: `MediaCodecList(REGULAR_CODECS)` → best **hardware** AVC (and HEVC) encoder; `VideoCapabilities` → `isSizeSupported`, `areSizeAndRateSupported`, `getAchievableFrameRatesFor`, `getBitrateRange`, alignments, `isBitrateModeSupported`; reject software-only encoders for > 1080p.
- Device: `ActivityManager.isLowRamDevice()`, `getMemoryClass()`, `MemoryInfo.totalMem`, `Build.VERSION.MEDIA_PERFORMANCE_CLASS` (API 31+, 0 if undeclared), SoC string.
- GL: renderer/version strings, `GL_MAX_TEXTURE_SIZE`, fragment `highp` support, ES3 availability, `EGL_IMG_context_priority`, `GL_EXT_disjoint_timer_query`.
- Runtime state: thermal status, battery %, power-save, charging, free storage.

**Tiers (starting point; refine with calibration):**

| Tier | Typical device | Video | Photo | Notes |
|---|---|---|---|---|
| **A flagship** | perf-class ≥ 31 or measured ≥ 20 fps @ 2160p | up to 2160p (2×), HEVC optional, sharpen low/med | 2× up to 48 MP, JPEG 95–98 | |
| **B mid (sweetin)** | HW AVC encoder 4K, ≥ 6 GB RAM | 2160p for short clips/cool device; otherwise 1440p; H.264; sharpen low | 2× up to 24 MP, JPEG 98 (40 MP only if ≥ 6 GB and tiled) | |
| **C low** | HW encoder ≤ 1440p or ≤ 4 GB RAM | 1080p→1440p (1.33×) or 1080p output with sharpen only | ≤ 16 MP output, tiled, JPEG 95 | |
| **D potato** | software-only encoder, no highp fragment, ≤ 2–3 GB RAM, `isLowRamDevice` | **Video SR off** | optional: 1.5× CPU/GL at ≤ 12 MP, or off | never hurt capture |

**Calibration + adaptation:**

1. First run (or after changes): process ~20 frames of the real clip, record `msPerFrame` at the chosen tier, cache `{device, tier, msPerFrame, thermal}`.
2. Projected cost policy as in §5.3; if the 2160p projection is poor, **restart** at the next tier within the first ~5 % (the encoder can't change resolution mid-stream).
3. Runtime: thermal `MODERATE` → pacing; `SEVERE` → pause; `CRITICAL` → abort. Battery/power-save → "only when charging" or lower tier. `ERROR_INSUFFICIENT_RESOURCE` → wait and retry.
4. **Configure ladder** for the encoder (this is what makes potato devices work): on `configure()` failure retry with progressively fewer/lower settings — (1) drop `KEY_PROFILE/LEVEL`; (2) drop `KEY_BITRATE_MODE`; (3) drop colour keys and `KEY_PRIORITY/OPERATING_RATE`; (4) lower the resolution one tier; (5) lower bitrate; (6) H.264 instead of HEVC; (7) give up and disable SR with a log line. Log which rung succeeded.
5. **User settings (all optional):** Video SR: Auto / 2160p / 1440p / 1080p / Off; Codec: H.264 / HEVC; Sharpening: Off / Low / Medium; Max length; "Only while charging"; "Pause when device is hot"; Photo: Off / 2× standard / 2× max; Save mode: MediaStore / file; "Delete original after success" (off by default).

---

## 8. Photo path hardening (not asked directly, but part of "all problems")

1. **Tile the GL work.** A 24 MP RGBA output is 96 MB per buffer; 40 MP is 160 MB. A whole-image FBO + readback buffer + `Bitmap` triples that. Instead: fixed-size FBO (e.g. 2048×2048 or 1024 rows), sampler = full source texture, `uTileOrigin` uniform, `glReadPixels` per tile into **one reusable** direct `ByteBuffer`, then draw/copy into the final `Bitmap`. Flip Y in the vertex shader so readback is already top-down. Check `GL_MAX_TEXTURE_SIZE` before uploading the source (fall back to CPU or scale if the source exceeds it).
2. **Memory budget gate:** `if (isLowRamDevice() || Runtime.maxMemory() < …)` cap output megapixels (see tier table). Reject jobs that would need > ~35 % of `MemoryInfo.availMem`.
3. **JPEG:** quality 95–98. q100 is ~1.5× the size for no visible gain. `Bitmap.compress` needs the whole bitmap; if you need strip-wise encoding for very large outputs, that means native libjpeg-turbo (`jpeg_write_scanlines`) — a later optimization.
4. **EXIF/metadata:** copy EXIF from the original with `androidx.exifinterface`/`ExifInterface` (make/model, `DateTimeOriginal`, GPS, exposure data), then **fix** `PixelXDimension/PixelYDimension` and reset `Orientation` to the correct value. Preserve color space tags. Keep any XMP your gallery relies on, or consciously drop it.
5. **Source bitmaps:** software `ARGB_8888` only (no HARDWARE config) for `GLUtils.texImage2D`; set NPOT-safe texture params; opaque output (alpha forced to 1).
6. **Save** through §5.1 (images use `MediaStore.Images`, `IS_PENDING`, `DCIM/Camera`); keep the original unless the user opts to replace.
7. **Fallback chain:** GL tiled → RenderScript (only if present) → CPU Lanczos at a reduced megapixel cap. Log which path ran.

---

## 9. Test matrix and acceptance criteria

**Video clips (each verified with `ffprobe -show_streams -show_format`, MediaStore row, gallery visibility, playback):**

| # | Case | What it catches |
|---|---|---|
| 1 | 1–2 s 1080p24 | basic pipeline, frame count equals source (34 in → 34 out) |
| 2 | 10 s, 30 s 1080p | throughput, thermal, memory flat over time |
| 3 | Portrait (rotation 90) and 270, plus 180 | rotation strategy B, orientation hint |
| 4 | No audio track | muxer with video only |
| 5 | Audio longer than video; audio starting late | clipping, A/V sync (clap test) |
| 6 | VFR clip; 60 fps clip (decimate); slow-mo | PTS preservation, decimation |
| 7 | 1088-coded/1080-display (crop) | transform matrix, no green bar |
| 8 | Odd dimensions | alignment, `isSizeSupported` |
| 9 | HEVC source, 10-bit/HLG source | decoder variety; HDR skip path |
| 10 | Already 4K source | skip (no upscale) |
| 11 | SMPTE bars + gray ramp | colour fidelity, clipping |
| 12 | Cancel mid-way; kill process mid-way; airplane/no-storage | no litter, cleanup on next start |
| 13 | Low-storage start; storage fills mid-job | pre-check + abort |
| 14 | Two videos recorded back-to-back; recording while a job runs | queueing, codec resource errors |
| 15 | Job running + user switches app / screen off | FGS survival, notification |
| 16 | Thermal stress (several 30 s clips) | pacing/pause/abort policy |

**Photos:** 12 MP, 24 MP, 4K-ish crop, extreme aspect (panorama), low light (noise), portrait with face, EXIF/GPS preserved, low-RAM simulation.

**Acceptance (per job):**

- `decoded == rendered == encoded` (±1 for EOS), output duration within ±1 frame of source video duration, audio present iff source had it and within ±40 ms sync.
- Output ≥ 64 KB, validates, appears in the gallery **once**, correct orientation/colour, no visible green/black frames.
- Zero main-thread stalls > 100 ms attributable to the job (heartbeat log), no ANR in 20 consecutive jobs.
- Memory flat: Java heap and native heap don't grow across 20 jobs.
- On failure: no output file/row remains; one clear notification; one log file with the reason.

---

## 10. Work plan for the subagent

**Phase 1 — correctness (1 build):** §2.3 pipeline (surface path only; no sharpening yet, plain Pass 2 bilinear), EGL config per §2.7, counters + end-of-job validation, MediaStore pending save (§5.1) + stale cleanup, `ApplicationExitInfo` + file log. Test cases 1, 3, 4, 5, 12. Exit criterion: valid MP4s, frame counts match, no litter.

**Phase 2 — stability and policy:** audio interleave + clipping, capability probe + configure ladder, thermal/storage/battery policy, FGS + notification progress, low-priority GL context, cancel. Test cases 2, 6–10, 13–16.

**Phase 3 — quality:** Catmull-Rom shader with limiter and gentle sharpen (§4.1), remove the contrast stretch for video, colour tags, A/B with SGSR1 on Adreno, bitrate tuning. Test case 11 and visual A/B.

**Phase 4 — UI:** thumbnail opener via intent/`startActivity` choke point (§6.1–6.2), rainbow bar rewrite and anchoring (§6.3), settings screen.

**Phase 5 — scale-out:** photo tiling and memory gates (§8), tier table and calibration on at least one low-end device, optional `:sr` process with `Application` guard, optional Media3 route.

Ask for **evidence, not claims**, after each phase: the one-line job summary log (`decoded/rendered/encoded/muxStarted/heapFree`), `ffprobe` output, and a `dumpsys activity exit-info` after a soak test.

---

## 11. What I could not verify (measure first)

1. **Your shader's actual formula** (B-spline vs Catmull-Rom; precision; texture state) — §4.3 is a checklist, not a verdict.
2. **The source of `frames=91`** — only the arithmetic is certain; the cause needs the proposed logging.
3. **Whether the decoder honours `KEY_ROTATION = 0` / what the transform matrix contains** on this vendor stack for rotated clips.
4. **Whether `KEY_PRIORITY`, `KEY_OPERATING_RATE`, `KEY_MAX_B_FRAMES`, colour keys are honoured** by `c2.qti.avc.encoder` here.
5. **Whether Adreno 618's driver on this ROM honours `EGL_IMG_context_priority`** (query the context after creation).
6. **All throughput/thermal numbers** (§3.5) — they come from fetch-count arithmetic, not measurements.
7. **ColorOS Gallery's package/activity names** and whether it syncs strictly through MediaStore.
8. **Framework-side behaviour on a ported ROM** (FGS type handling, background limits, MediaProvider quirks) when the framework is newer than the vendor stack.
9. **Whether a watchdog-triggered `encoder.release()` reliably unblocks a stuck `eglSwapBuffers`** here.
10. **The exact smali location** of GCam's thumbnail intent builder in LMC 8.4 R17.

---

## 12. References (read these, don't copy blindly)

- AOSP CTS `DecodeEditEncodeTest`, `ExtractDecodeEditEncodeMuxTest`, and helper classes `InputSurface` / `OutputSurface` (`android.googlesource.com/platform/cts`, `tests/tests/media`) — the canonical decoder→GL→encoder surface pipeline and EGL config.
- grafika (Google, `google/grafika`) — `EglCore`, `WindowSurface`, `VideoEncoderCore`, `TextureMovieEncoder`, continuous-capture and movie-player samples.
- Android docs: `MediaCodec`, `MediaFormat` keys (`KEY_ROTATION`, `KEY_PRIORITY`, `KEY_OPERATING_RATE`, colour keys), `MediaCodecInfo.VideoCapabilities`, `SurfaceTexture` (source.android.com graphics architecture: SurfaceTexture), `MediaStore` (`IS_PENDING`, `DATE_EXPIRES`, `QUERY_ARG_MATCH_PENDING`), `ApplicationExitInfo` (`getTraceInputStream`), `PowerManager` thermal API.
- Khronos `EGL_IMG_context_priority`, `EGL_ANDROID_recordable`, `EGL_ANDROID_presentation_time`.
- Qualcomm Snapdragon Game Super Resolution (SGSR1, BSD-3-Clause) and AMD FidelityFX FSR 1.0 EASU/RCAS (MIT) — keep license headers if you port shaders.
- Catmull-Rom 9-tap bilinear-trick sampling (J. Jimenez; popularised by M. Pettineo) and GPU Gems 2 "fast third-order texture filtering" (B-spline, 4 taps) for the distinction in §4.3.
- Media3 Transformer (Jetpack) — decode→GL effects→encode with progress/cancel and vendor workarounds.
- SuperImage (MNN + Real-ESRGAN on Android) — public benchmark used in §4.2.
